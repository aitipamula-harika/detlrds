USE msdb
GO

--DECLARE @Database_To_Backup VARCHAR(100)
DECLARE @Job_Name VARCHAR(1000)
DECLARE @Job_Owner VARCHAR(100)


--SET @Database_To_Backup = '<<DatabaseName>>'
--SET @Database_To_Backup = 'sql_whatiscod4_dvl01_01'


SET @Job_Name = 'Backup_DB_PowerShell'

--SET @Job_Owner = '<<DomainName>>\<<SQLServiceAccountUsername>>'
SET @Job_Owner = 'sa'


DECLARE @Backup_Statement NVARCHAR(MAX)

SET @Backup_Statement = '#NOSQLPS
Import-Module SqlServer
Import-Module AWSPowerShell


<#
    This function returns Credentials object for SQL SA user.
#>
function GetCredentialsObjectForSQLSAUser{

    param(

        $EnvironmentAbbriviation,
        $ApplicationBlockCode,
        $SAPasswordSecretKeyName

    )

    #$EnvironmentAbbriviation = "dvl"
    #$ApplicationBlockCode = "whatiscod4"
    #Write-Host "SA Password Secret Key is ${EnvironmentAbbriviation}/${ApplicationBlockCode}/SAPassword"

    $SAPasswordSecretKey = "${EnvironmentAbbriviation}-${ApplicationBlockCode}-${SAPasswordSecretKeyName}"
    
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "SA password not found in secrets manager. Stopping the installation"
        throw "SA password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString | ConvertFrom-Json
    
    $SQLSAPasswordPT = $null

    if ($SQLSAPasswordSS.username -eq "sa")
    {
        $SQLSAPasswordPT = $SQLSAPasswordSS.password
    }
    else
    {
        Write-Host "Username in the password payload is not sa. Stopping the installation."
        throw "Username in the password payload is not sa. Stopping the installation."
    }
    #Write-Host "SA Password $SQLSAPasswordPT"

    $SAPasswordAsStringPassword = ConvertTo-SecureString $SQLSAPasswordPT -AsPlainText -Force


    return New-Object System.Management.Automation.PSCredential (''sa'', $SAPasswordAsStringPassword)


}



# Get the instance id
$EC2InstanceId = Get-EC2InstanceMetadata -Category InstanceId

# get all the tags for the instance
$EC2Tags = (Get-EC2Tag -Filter @{Name="resource-type";Values="instance"},@{Name="resource-id";Values=$EC2InstanceId}) | Select-Object Key, Value

$EnvironmentTag = $EC2Tags | ?{ $_.Key -eq "Environment" }

$CloudFormationStackNameTagKey = "aws:cloudformation:stack-name"

# get the stack name tag
$CFTStackNameTag = $EC2Tags | ?{ $_.Key -eq "$CloudFormationStackNameTagKey" }

# get the CloudFormation stack
$CFNStack = Get-CFNStack -StackName $CFTStackNameTag.Value

# Get ApplocationBlockCode param frrm CFT
$ApplicationBlockCodeParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "applicationBlockCode"} | select ParameterValue

$ApplicationBlockCodeParamValue = $ApplicationBlockCodeParam.ParameterValue

# grab SAPassword Secret Name Param from CFT
$SAPasswordSecretKeyNameParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "SAPasswordSecretName"} | select ParameterValue

$EnvironmentAbbriviation = $EnvironmentTag.Value

$SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentAbbriviation -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

$AllDBs = Get-SqlDatabase -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

# Lets get the datetime in the right format.
$CurrentDateTimeObj = Get-Date
$BackupTime = $CurrentDateTimeObj.ToString("yyyy_MM_dd_hhmmss_fffffff")
$ExcludeDBFromBackup = @("model","tempdb")
$ExcludeDBLogForBackp = @("master","msdb")

$AllDBs.ForEach({
    if ($_.Name -in $ExcludeDBFromBackup)
    {
        return   
    }

	$DatabaseToBackup = $_.Name
    $BackupLocation = "I:\DBBackups"
    $S3BucketNameToPushBackupFilesAt = "delta-rds-artifacts"
    $BaseS3KeyLocationToPushBackupFilesAt = "mssql/backups"

	# lets construct backup file name
    $DBBckupFileName = "${DatabaseToBackup}_backup_${BackupTime}_database.bak"
    $LogBackupFileName = "${DatabaseToBackup}_backup_${BackupTime}_log.bak"

    $DBBckupFileFullPath = Join-Path -Path $BackupLocation -ChildPath $DBBckupFileName
    $LogBckupFileFullPath = Join-Path -Path $BackupLocation -ChildPath $LogBackupFileName

    Backup-SqlDatabase -ServerInstance "$env:COMPUTERNAME" -BackupFile "$DBBckupFileFullPath" -Database $DatabaseToBackup -RetainDays 14 -SkipTapeHeader -CompressionOption On -StatementTimeout 10 -BackupAction Database -Credential $SACredObject 

    if ($_.Name -notin $ExcludeDBLogForBackp)
    {
        Backup-SqlDatabase -ServerInstance "$env:COMPUTERNAME" -BackupFile "$LogBckupFileFullPath" -Database $DatabaseToBackup -RetainDays 14 -SkipTapeHeader -CompressionOption On -StatementTimeout 10 -BackupAction Log -Credential $SACredObject 
    }

    $DBBackFileS3Key = "{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}" -f $BaseS3KeyLocationToPushBackupFilesAt, $EnvironmentAbbriviation, $CurrentDateTimeObj.Year, $CurrentDateTimeObj.ToString("MM"), $CurrentDateTimeObj.ToString("dd"), $ApplicationBlockCodeParamValue, $DatabaseToBackup, $DBBckupFileName

    $LogBackFileS3Key = "{0}/{1}/{2}/{3}/{4}/{5}/{6}/{7}" -f $BaseS3KeyLocationToPushBackupFilesAt, $EnvironmentAbbriviation, $CurrentDateTimeObj.Year, $CurrentDateTimeObj.ToString("MM"), $CurrentDateTimeObj.ToString("dd"), $ApplicationBlockCodeParamValue, $DatabaseToBackup, $LogBackupFileName


    Write-S3Object -BucketName $S3BucketNameToPushBackupFilesAt -Key $DBBackFileS3Key -File $DBBckupFileFullPath
    
    if ($_.Name -notin $ExcludeDBLogForBackp)
    {

        Write-S3Object -BucketName $S3BucketNameToPushBackupFilesAt -Key $LogBackFileS3Key -File $LogBckupFileFullPath
    }
	
})

'

PRINT(@Backup_Statement)
--EXEC SP_EXECUTESQL @Backup_Statement

EXEC sp_add_job 
	@job_name = @Job_Name,
	@owner_login_name=@Job_Owner,
	@enabled = 1,
	@notify_level_eventlog=2, 
	@notify_level_email=3, 
	@notify_email_operator_name=N'DBA'


EXEC dbo.sp_add_jobserver  
    @job_name = @Job_Name



EXEC sp_add_jobstep
    @job_name = @Job_Name,
    @step_name = 'Step_Backup',
    @subsystem = N'PowerShell',
    @command = @Backup_Statement

EXEC sp_add_jobschedule 
		@name='Backup_Schedule',
		@job_name=@Job_Name, 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20220103, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959


		