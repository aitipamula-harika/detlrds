USE [master] 
GO

EXEC sp_configure 'show advanced options',1
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sp_configure 'Database Mail XPs',1
GO
RECONFIGURE 
GO


/*
STEP 01 - 
CREATE MAIL PROFILE 
-------------------------------------------------
*/

USE [msdb]
GO

DECLARE @retVal_ProfileName NVARCHAR(20)
DECLARE @retVal_ProfileDesc NVARCHAR(200)

SET @retVal_ProfileName = 'default'
SET @retVal_ProfileDesc = 'default mail profile'


IF (SELECT COUNT(*) 
FROM  msdb.dbo.sysmail_profile
WHERE name = @retVal_ProfileName) > 0

BEGIN
EXECUTE msdb.dbo.sysmail_delete_profile_sp  
@profile_name = @retVal_ProfileName ; 
END

-- Create a New Mail Profile
EXECUTE msdb.dbo.sysmail_add_profile_sp
       @profile_name = @retVal_ProfileName, 
       @description = @retVal_ProfileDesc

/*
STEP 02 - 
Set the New Profile as the Default
-------------------------------------------------
*/

EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @profile_name = @retVal_ProfileName, 
    @principal_name = 'public',
    @is_default = 1 ;
GO




/*
STEP 03 - 
Create an Account
-------------------------------------------------
*/


DECLARE @account_ID INTEGER
DECLARE @account_name nvarchar(50)

SELECT @account_name = 'smtp.delta.com'
SELECT @account_ID = 
(
SELECT TOP 1 account_id 
FROM  msdb.dbo.sysmail_account
WHERE DATEDIFF(d,last_mod_datetime, getdate()) = 0
)

IF (@account_ID > 0)
BEGIN
EXECUTE msdb.dbo.sysmail_delete_account_sp  
@account_ID, @account_name
   
END

EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name = @account_name,
    @description = 'smtp.delta.com',
    @email_address = 'IBMDeltaZuluDBAMigrationSupport@delta.com',
    @display_name = 'IBMDeltaZuluDBAMigrationSupport@delta.com',
    @mailserver_name = 'smtp.delta.com'
GO

-- Add the Account to the Profile
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
    @profile_name = 'default',
    @account_name = 'smtp.delta.com',
    @sequence_number = 1
GO



/*
STEP 04 - 
Add Operator
-------------------------------------------------
*/

USE [msdb]
GO

DECLARE @name nvarchar(50)

SET @name = 'DBA'

IF (EXISTS (SELECT *
                  FROM msdb.dbo.sysoperators
                  WHERE (name = @name)))
  BEGIN
EXEC sp_delete_operator @name = @name ;

  END

EXEC msdb.dbo.sp_add_operator @name= @name, 
@enabled=1, 
@weekday_pager_start_time=90000, 
@weekday_pager_end_time=180000, 
@saturday_pager_start_time=90000, 
@saturday_pager_end_time=180000, 
@sunday_pager_start_time=90000, 
@sunday_pager_end_time=180000, 
@pager_days=0, 
@email_address=N'IBMDeltaZuluDBAMigrationSupport@delta.com', 
@category_name=N'[Uncategorized]'
GO

/*
STEP 05 -
Enable Database Mail
*/
USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1, 
		@databasemail_profile=N'default', 
		@use_databasemail=1
GO