﻿Import-Module SqlServer
Import-Module AWSPowerShell

function GetCredentialsObjectForSQLSAUser{

    param(

        $EnvironmentAbbriviation,
        $ApplicationBlockCode,
        $SAPasswordSecretKeyName

    )

    #$EnvironmentAbbriviation = "dvl"
    #$ApplicationBlockCode = "whatiscod4"
    #Write-Host "SA Password Secret Key is ${EnvironmentAbbriviation}/${ApplicationBlockCode}/SAPassword"

    $SAPasswordSecretKey = "${EnvironmentAbbriviation}-${ApplicationBlockCode}-${SAPasswordSecretKeyName}"
    
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "SA password not found in secrets manager. Stopping the installation"
        throw "SA password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString | ConvertFrom-Json
    
    $SQLSAPasswordPT = $null

    if ($SQLSAPasswordSS.username -eq "sa")
    {
        $SQLSAPasswordPT = $SQLSAPasswordSS.password
    }
    else
    {
        Write-Host "Username in the password payload is not sa. Stopping the installation."
        throw "Username in the password payload is not sa. Stopping the installation."
    }
    #Write-Host "SA Password $SQLSAPasswordPT"

    $SAPasswordAsStringPassword = ConvertTo-SecureString $SQLSAPasswordPT -AsPlainText -Force


    return New-Object System.Management.Automation.PSCredential ('sa', $SAPasswordAsStringPassword)


}



# Get the instance id
$EC2InstanceId = Get-EC2InstanceMetadata -Category InstanceId

# get all the tags for the instance
$EC2Tags = (Get-EC2Tag -Filter @{Name="resource-type";Values="instance"},@{Name="resource-id";Values=$EC2InstanceId}) | Select-Object Key, Value

$EnvironmentTag = $EC2Tags | ?{ $_.Key -eq "Environment" }

$CloudFormationStackNameTagKey = "aws:cloudformation:stack-name"

# get the stack name tag
$CFTStackNameTag = $EC2Tags | ?{ $_.Key -eq "$CloudFormationStackNameTagKey" }

# get the CloudFormation stack
$CFNStack = Get-CFNStack -StackName $CFTStackNameTag.Value


# Get ApplocationBlockCode param frrm CFT
$ApplicationBlockCodeParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "applicationBlockCode"} | select ParameterValue

# grab SAPassword Secret Name Param from CFT
$SAPasswordSecretKeyNameParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "SAPasswordSecretName"} | select ParameterValue

$SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

#$AllDBs = Get-SqlDatabase -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

$GetActiveWorkerThreadPercentageQuery = "USE master; SELECT CAST(CAST(SUM(active_workers_count) AS FLOAT)/CAST((SELECT max_workers_count FROM sys.dm_os_sys_info )  AS FLOAT)*100 AS DECIMAL(3,2)) AS 'ActiveWorkerThreadPercentage' FROM sys.dm_os_schedulers where status = 'VISIBLE ONLINE'	;"

$ActiveWorkerThreadPercentage = Invoke-Sqlcmd -Query "$GetActiveWorkerThreadPercentageQuery" -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

Write-Host "Max Worker Percent is $($ActiveWorkerThreadPercentage.ActiveWorkerThreadPercentage)"

$Metric = New-Object -TypeName Amazon.CloudWatch.Model.MetricDatum
$Metric.Timestamp = [DateTime]::UtcNow
$Metric.MetricName = "Max Worker Percent"
$Metric.Value = $ActiveWorkerThreadPercentage.ActiveWorkerThreadPercentage
$Metric.Unit = [Amazon.CloudWatch.StandardUnit]::Percent

$MetricDimInstId = New-Object -TypeName Amazon.CloudWatch.Model.Dimension
$MetricDimInstId.Name = "InstanceId"
$MetricDimInstId.Value = Get-EC2InstanceMetadata -Category InstanceId
$Metric.Dimensions.Add($MetricDimInstId)

$MetricDimDBName = New-Object -TypeName Amazon.CloudWatch.Model.Dimension
$MetricDimDBName.Name = "DatabaseName"
$MetricDimDBName.Value = "master"
$Metric.Dimensions.Add($MetricDimDBName)

    
Write-CWMetricData -Namespace "MSSQL-On-EC2" -MetricData $Metric

