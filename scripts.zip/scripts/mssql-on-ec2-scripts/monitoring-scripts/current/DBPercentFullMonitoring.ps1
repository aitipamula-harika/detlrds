﻿Import-Module SqlServer
Import-Module AWSPowerShell


<#
    This function returns Credentials object for SQL SA user.
#>
function GetCredentialsObjectForSQLSAUser{

    param(

        $EnvironmentAbbriviation,
        $ApplicationBlockCode,
        $SAPasswordSecretKeyName

    )

    #$EnvironmentAbbriviation = "dvl"
    #$ApplicationBlockCode = "whatiscod4"
    #Write-Host "SA Password Secret Key is ${EnvironmentAbbriviation}/${ApplicationBlockCode}/SAPassword"

    $SAPasswordSecretKey = "${EnvironmentAbbriviation}-${ApplicationBlockCode}-${SAPasswordSecretKeyName}"
    
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "SA password not found in secrets manager. Stopping the installation"
        throw "SA password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString | ConvertFrom-Json
    
    $SQLSAPasswordPT = $null

    if ($SQLSAPasswordSS.username -eq "sa")
    {
        $SQLSAPasswordPT = $SQLSAPasswordSS.password
    }
    else
    {
        Write-Host "Username in the password payload is not sa. Stopping the installation."
        throw "Username in the password payload is not sa. Stopping the installation."
    }
    #Write-Host "SA Password $SQLSAPasswordPT"

    $SAPasswordAsStringPassword = ConvertTo-SecureString $SQLSAPasswordPT -AsPlainText -Force


    return New-Object System.Management.Automation.PSCredential ('sa', $SAPasswordAsStringPassword)


}



# Get the instance id
$EC2InstanceId = Get-EC2InstanceMetadata -Category InstanceId

# get all the tags for the instance
$EC2Tags = (Get-EC2Tag -Filter @{Name="resource-type";Values="instance"},@{Name="resource-id";Values=$EC2InstanceId}) | Select-Object Key, Value

$EnvironmentTag = $EC2Tags | ?{ $_.Key -eq "Environment" }

$CloudFormationStackNameTagKey = "aws:cloudformation:stack-name"

# get the stack name tag
$CFTStackNameTag = $EC2Tags | ?{ $_.Key -eq "$CloudFormationStackNameTagKey" }

# get the CloudFormation stack
$CFNStack = Get-CFNStack -StackName $CFTStackNameTag.Value

# Get ApplocationBlockCode param frrm CFT
$ApplicationBlockCodeParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "applicationBlockCode"} | select ParameterValue

# grab SAPassword Secret Name Param from CFT
$SAPasswordSecretKeyNameParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "SAPasswordSecretName"} | select ParameterValue



$SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue


$AllDBs = Get-SqlDatabase -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

$AllDBs.ForEach({
    #Write-Host $_.Name
    $GetSpaceUsedQuery = "USE $($_.Name); EXEC SP_SPACEUSED @oneresultset=1;"
    #Write-Host $GetSpaceUsedQuery
    $SpaceUsed = Invoke-Sqlcmd -Query "$GetSpaceUsedQuery" -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject
    $DBTotalSize = $SpaceUsed.database_size.TrimEnd(" MB")
    $DBUnusedSpace = $SpaceUsed.'unallocated space'.TrimEnd(" MB")
    $DBPercentFull = (($DBTotalSize-$DBUnusedSpace)/$DBTotalSize)*100
    $DBPercentFull = [math]::Round($DBPercentFull,2)

    $Metric = New-Object -TypeName Amazon.CloudWatch.Model.MetricDatum
    $Metric.Timestamp = [DateTime]::UtcNow
    $Metric.MetricName = "Database Full (Percent)"
    $Metric.Value = $DBPercentFull
    $Metric.Unit = [Amazon.CloudWatch.StandardUnit]::Percent

    $MetricDimInstId = New-Object -TypeName Amazon.CloudWatch.Model.Dimension
    $MetricDimInstId.Name = "InstanceId"
    $MetricDimInstId.Value = Get-EC2InstanceMetadata -Category InstanceId
    $Metric.Dimensions.Add($MetricDimInstId)

    $MetricDimDBName = New-Object -TypeName Amazon.CloudWatch.Model.Dimension
    $MetricDimDBName.Name = "DatabaseName"
    $MetricDimDBName.Value = $_.Name
    $Metric.Dimensions.Add($MetricDimDBName)

    
    Write-CWMetricData -Namespace "MSSQL-On-EC2" -MetricData $Metric


    #Write-Host "Databse $($_.Name) is $DBPercentFull % full"
    
    }
)



