import boto3
from os import getenv
import sys
import json
import argparse

parser = argparse.ArgumentParser()

# parser.add_argument("-b","--blockcode", help="Enter block code", required=True)
# parser.add_argument("-e","--dbengine", help="Enter Database engine i.e. Oracle, DB2",required=True)
# parser.add_argument("-n","--dbnumber", help="Enter database number i.e. 01 or 02", required=True)
# parser.add_argument("-d","--destregion", help="Enter destination region  i.e. us-west-2", default="us-west-2")

parser.add_argument("-d","--dbinstanceidentifier", help="DB instance identifier", required=True)
parser.add_argument("-r","--destregion", help="Destination region  i.e. us-west-2", default="us-west-2")

args = parser.parse_args()

def main():
    print("setting up secret replication")

    # block_code = getenv("BlockCode", "salpadbcd1")
    # db_engine = getenv("DatabaseEngine", "Oracle")
    # db_number = getenv("DatabaseNumber", "01")
    # dest_region = getenv("DestinationRegion", "us-west-2")

    db_instance_identifier = args.dbinstanceidentifier
    # db_instance_identifier = "ora-salpadbcd1-dev-01"

    block_code = db_instance_identifier.split(sep="-")[1]
    db_engine_abbr = db_instance_identifier.split(sep="-")[0]
    db_number = db_instance_identifier.split(sep="-")[3]
    dest_region = args.destregion
    # dest_region = "us-west-2"

    print(f"Block code: {block_code}")
    print(f"DB engine: {db_engine_abbr}")
    print(f"DB Number: {db_number}")

    # db_engine_abbr_dict = {"Oracle": "ora", "DB2": "db2"}
    environment_abbr_dict = {"sandbox": "sbx", "development": "dev",
                             "systems-integration": "si", "production": "prd"}

    # db_engine_abbr = db_engine

    if db_engine_abbr is None:
        error_message = "ERROR: Invalid DB Engine value supplied"
        print(error_message)
        sys.exit(error_message)

    print(f"DB Engine value supplied: {db_engine_abbr}")
    print(f"DB Engine abbriviation will be : {db_engine_abbr}")

    # Now lets get the current environment from paramter store

    ssm_client = boto3.client('ssm')

    get_environment_parameter_response = ssm_client.get_parameter(
        Name='/delta/account/environment:1'
    )

    if get_environment_parameter_response is None:
        error_message = "ERROR: Environment parameter not found"
        print(error_message)
        sys.exit(error_message)

    if "Parameter" in get_environment_parameter_response:
        if "Value" in get_environment_parameter_response["Parameter"]:
            current_env_full_name = get_environment_parameter_response["Parameter"]["Value"]

    if current_env_full_name is None:
        error_message = "ERROR: Unable to get Environment parameter value"
        print(error_message)
        sys.exit(error_message)

    print(f"Current Environment Full Name: {current_env_full_name}")

    current_env_abbr = environment_abbr_dict.get(current_env_full_name)

    if current_env_abbr is None:
        error_message = "ERROR: Invalid Environment"
        print(error_message)
        sys.exit(error_message)

    print(f"Current environment abbriviation will be : {current_env_abbr}")


    # Now lets get the current hosted zone domain from paramter store

    get_hosted_zone_parameter_response = ssm_client.get_parameter(
        Name='/delta/r53/hostedzonename:1'
    )

    if get_hosted_zone_parameter_response is None:
        error_message = "ERROR: Hosted zone parameter not found"
        print(error_message)
        sys.exit(error_message)

    if "Parameter" in get_hosted_zone_parameter_response:
        if "Value" in get_hosted_zone_parameter_response["Parameter"]:
            current_hosted_zone_name = get_hosted_zone_parameter_response["Parameter"]["Value"]

    if current_hosted_zone_name is None:
        error_message = "ERROR: Unable to get Hosted Zone parameter value"
        print(error_message)
        sys.exit(error_message)

    print(f"Current Hosted zone is: {current_hosted_zone_name}")

    # now lets construct secret name

    source_secret_name = f"{db_engine_abbr}-{block_code}-{current_env_abbr}-{db_number}-credentials"

    print(f"Secret {source_secret_name} will be replicated")

    secretsmanager_client = boto3.client('secretsmanager')

    get_secret_response = secretsmanager_client.describe_secret(
        SecretId=source_secret_name
    )

    if get_secret_response is None:
        error_message = "ERROR: Unable to get secret. Either it does not exist or we do not have access to it"
        print(error_message)
        sys.exit(error_message)

    print(f"secret {source_secret_name} exists.")

    source_secret_arn = get_secret_response["ARN"]
    source_secret_arn_parts = source_secret_arn.split(":")
    destination_secret_arn = ":".join(source_secret_arn_parts[0:3] + [dest_region] + source_secret_arn_parts[4:])

    # now lets construct destination KMS key

    dest_kms_key_alias = f"{db_engine_abbr}-{block_code}-{current_env_abbr}-{db_number}-dbuser-secret-cmk"

    print(
        f"KMS key {dest_kms_key_alias} in region {dest_region} will be used to encrypt the secret")

    kms_client = boto3.client('kms')

    describe_key_response = kms_client.describe_key(
        KeyId=f'alias/{dest_kms_key_alias}'
    )

    if describe_key_response is None:
        error_message = f"ERROR: Unable to get KMS key {dest_kms_key_alias} in destination region {dest_region}. Either it does not exist or we do not have access to it"
        print(error_message)
        sys.exit(error_message)

    print(
        f"KMS Key {dest_kms_key_alias} exists in destination region {dest_region}.")

    # now lets grab the secret so we can update host

    secret_value = secretsmanager_client.get_secret_value(
        SecretId=source_secret_name,
    )

    if secret_value is None:
        error_message = f"ERROR: Unable to get secret value. Most probably we do not have access to it"
        print(error_message)
        sys.exit(error_message)

    if "SecretString" in secret_value:
        secret_string = json.loads(secret_value["SecretString"])
        if "host" in secret_string:
            host_existing_value = secret_string['host']
            print(f"Current value for the host is {host_existing_value}")

    if host_existing_value is None:
        error_message = f"ERROR: Unable to find host key in secret."
        print(error_message)
        sys.exit(error_message)

    # now lets grab resource policy so we can update it to add new secret ARN

    resource_policy = secretsmanager_client.get_resource_policy(
        SecretId=source_secret_name,
    )

    if resource_policy is None:
        error_message = f"ERROR: Unable to get resource policy. Most probably we do not have access to it"
        print(error_message)
        sys.exit(error_message)




    

    if "ResourcePolicy" in resource_policy:
        resource_policy_json = json.loads(resource_policy["ResourcePolicy"])
        if "Statement" in resource_policy_json:
            for statement in resource_policy_json["Statement"]:
                if "Resource" in statement:
                    if isinstance(statement["Resource"],list):
                        if not destination_secret_arn in statement["Resource"]:
                            statement["Resource"].append(destination_secret_arn)
                    else:
                        if statement["Resource"] != destination_secret_arn:
                            statement["Resource"] = [statement["Resource"], destination_secret_arn]
    
    resource_policy = resource_policy_json


    
    # now lets construct CNAME for the host

    new_host_value = f"{db_engine_abbr}-{block_code}-{db_number}.{current_hosted_zone_name}"

    print(f"new host value will be {new_host_value}")
    # now lets update the host value

    secret_string["host"] = new_host_value


    put_secret_value_response = secretsmanager_client.put_secret_value(
        SecretId=source_secret_name,
        SecretString=json.dumps(secret_string)
    )


    # now lets setup replication

    replicate_secret_response = secretsmanager_client.replicate_secret_to_regions(
        SecretId=source_secret_name,
        AddReplicaRegions=[
            {
                'Region': dest_region,
                'KmsKeyId': f"alias/{dest_kms_key_alias}"
            },
        ]
    )

    # now lets update the resource policy
    put_resource_policy_value_response = secretsmanager_client.put_resource_policy(
        SecretId=source_secret_name,
        ResourcePolicy=json.dumps(resource_policy)
    )



    print(f"Replication of Secret {source_secret_name} to region {dest_region} setup successfully")


if __name__ == "__main__":
    main()
