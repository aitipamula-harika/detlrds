#!/bin/sh

echo "------------------Input Parameters----------------------------------------"
echo ""

echo "Source DB Instance Identifier : $1"
SourceDBInstanceIdentifier=$1
echo "Renamed DB Instance Identifier : $2"
RenamedDBInstanceIdentifier=$2
echo "Target DB Instance Identifier: $3"
TargetDBInstanceIdentifier=$3
echo "Restore Point In time. Please enter in format yyyy-MM-ddThh:mm:ssZ: $4"
RestorePIT=$4
echo ""
echo "------------------------------------------------------------------------"

#download jq before making any progress
PWD="$(pwd)"
DIR="$PWD/jq"
if [ ! -d "$DIR" ]; then
        echo "Shell script uses jq utility. Downloading at location $DIRi "
        mkdir jq
        aws s3 cp s3://delta-postcfg-artifacts/database/tools/jq/jq-linux64 $DIR/jq
        chmod +x $DIR/jq
        export PATH=$PATH:$DIR
fi

if [ $RenamedDBInstanceIdentifier == 'DoNotRename' ]
then
        echo "you have selected not to rename the existing DB instance."
else
        aws rds modify-db-instance --db-instance-identifier $SourceDBInstanceIdentifier --new-db-instance-identifier $RenamedDBInstanceIdentifier --apply-immediately | jq '.DBInstances[0] .DBInstanceStatus'
        SourceDBInstanceIdentifier=$RenamedDBInstanceIdentifier
        echo ""
        echo "Sleeping for 120 seconds as renaming reboots instance and need time......."
        sleep 120
        aws rds wait db-instance-available --db-instance-identifier $RenamedDBInstanceIdentifier
        echo ""
fi

while  [ 1=1 ]
do
        result=$(aws rds describe-db-instances --db-instance-identifier $SourceDBInstanceIdentifier)
        command_status=$?
        if [ "${command_status}" -eq "1" ]; then
                echo "API call describe-db-instances returned exit code 1. Please check instance status."
                sleep 10
                break
        elif [ "${command_status}" -gt "1" ]; then
                echo "API call describe-db-instances returned bad exit code. Please check instance status. Error code=${command_status}"
                sleep 10
                break
        fi
        DBInstanceStatus=$(echo $result | jq '.DBInstances[0] .DBInstanceStatus')
        if [ "$DBInstanceStatus"=="\"available\"" ];
        then
                echo "Your RDS instance is available!"
                echo ""
                AutoMinorVersionUpgrade=$(echo $result | jq '.DBInstances[0] .AutoMinorVersionUpgrade')
                #echo "AutoMinorVersionUpgrade=$AutoMinorVersionUpgrade"
                AvailabilityZone=$(echo $result | jq '.DBInstances[0] .AvailabilityZone')
                AvailabilityZone=$(echo $AvailabilityZone | tr -d '"')
                #echo "AvailabilityZone=$AvailabilityZone"
                EnableIAMDatabaseAuthentication=$(echo $result | jq '.DBInstances[0] .IAMDatabaseAuthenticationEnabled')
                #echo "EnableIAMDatabaseAuthentication=$EnableIAMDatabaseAuthentication"
                DBParameterGroupName=$(echo $result | jq '.DBInstances[0]  .DBParameterGroups[0] .DBParameterGroupName')
                DBParameterGroupName=$(echo $DBParameterGroupName | tr -d '"')
                #echo "DBParameterGroupName=$DBParameterGroupName"
                VpcSecurityGroups=$(echo $result | jq '.DBInstances[0] .VpcSecurityGroups[0] .VpcSecurityGroupId')
                VpcSecurityGroups=$(echo $VpcSecurityGroups | tr -d '"')
                #echo "VpcSecurityGroups=$VpcSecurityGroups"
                DBSubnetGroupName=$(echo $result | jq '.DBInstances[0] .DBSubnetGroup .DBSubnetGroupName')
                DBSubnetGroupName=$(echo $DBSubnetGroupName | tr -d '"')
                #echo "DBSubnetGroupName=$DBSubnetGroupName"
                DeletionProtection=$(echo $result | jq '.DBInstances[0] .DeletionProtection')
                #echo "DeletionProtection=$DeletionProtection"
                EnableCloudwatchLogsExports=$(echo $result | jq '.DBInstances[0] .EnabledCloudwatchLogsExports')
                EnableCloudwatchLogsExports=$(echo $EnableCloudwatchLogsExports | tr -d '[]')
                EnableCloudwatchLogsExports=$(echo $EnableCloudwatchLogsExports | tr -d '",')
                #echo "EnableCloudwatchLogsExports=$EnableCloudwatchLogsExports"
                Iops=$(echo $result | jq '.DBInstances[0] .Iops')
                #echo "Iops=$Iops"
                MaxAllocatedStorage=$(echo $result | jq '.DBInstances[0] .MaxAllocatedStorage')
                #echo "MaxAllocatedStorage=$MaxAllocatedStorage"
                MultiAZ=$(echo $result | jq '.DBInstances[0] .MultiAZ')
                #echo "MultiAZ=$MultiAZ"
                StorageType=$(echo $result | jq '.DBInstances[0] .StorageType')
                StorageType=$(echo $StorageType | tr -d '"')
                #echo "StorageType=$StorageType"
                TagList=$(echo $result | jq '.DBInstances[0] .TagList')
                #echo "TagList=$TagList"
                PerformanceInsightsEnabled=$(echo $result | jq '.DBInstances[0] .PerformanceInsightsEnabled')
                echo "PerformanceInsightsEnabled=$PerformanceInsightsEnabled"
                PerformanceInsightsKMSKeyId=$(echo $result | jq '.DBInstances[0] .PerformanceInsightsKMSKeyId')
                PerformanceInsightsKMSKeyId=$(echo  $PerformanceInsightsKMSKeyId | tr -d '"')
                #echo "PerformanceInsightsKMSKeyId=$PerformanceInsightsKMSKeyId"
                PerformanceInsightsRetentionPeriod=$(echo $result | jq '.DBInstances[0] .PerformanceInsightsRetentionPeriod')
                echo "PerformanceInsightsRetentionPeriod=$PerformanceInsightsRetentionPeriod"
                EnhancedMonitoringResourceArn=$(echo $result | jq '.DBInstances[0] .EnhancedMonitoringResourceArn')
                EnhancedMonitoringResourceArn=$(echo  $EnhancedMonitoringResourceArn | tr -d '"')
                #echo "EnhancedMonitoringResourceArn=$EnhancedMonitoringResourceArn"
                MonitoringInterval=$(echo $result | jq '.DBInstances[0] .MonitoringInterval')
                #echo "MonitoringInterval=$MonitoringInterval"
                MonitoringRoleArn=$(echo $result | jq '.DBInstances[0] .MonitoringRoleArn')
                MonitoringRoleArn=$(echo  $MonitoringRoleArn | tr -d '"')
                #echo "MonitoringRoleArn=$MonitoringRoleArn"
                break
        fi

done

command="aws rds restore-db-instance-to-point-in-time --source-db-instance-identifier $SourceDBInstanceIdentifier "
command+="--target-db-instance-identifier $TargetDBInstanceIdentifier "
command+="--db-subnet-group-name $DBSubnetGroupName "
command+="--restore-time $RestorePIT "

if [ $AutoMinorVersionUpgrade == 'true' ]
then
        command+="--auto-minor-version-upgrade "
else
        command+="--no-auto-minor-version-upgrade "
fi

if [ $MultiAZ == 'true' ]
then
        command+="--multi-az "
else
        command+="--no-multi-az --availability-zone $AvailabilityZone "
fi

if [ $EnableIAMDatabaseAuthentication == 'true' ]
then
        command+="--enable-iam-database-authentication "
else
        command+="--no-enable-iam-database-authentication "
fi

if [ $DeletionProtection == 'true' ]
then
        command+="--deletion-protection "
else
        command+="--no-deletion-protection "
fi

command+="--db-parameter-group-name $DBParameterGroupName "
command+="--vpc-security-group-ids   $VpcSecurityGroups "
command+="--db-subnet-group-name  $DBSubnetGroupName "
command+="--enable-cloudwatch-logs-exports $EnableCloudwatchLogsExports "

if [ "$MaxAllocatedStorage" != 'null' ]
then
                command+="--max-allocated-storage $MaxAllocatedStorage "
fi

if [ "$Iops" == 'null' ]
then
        command+="--storage-type $StorageType "
else
        command+="--iops $Iops --storage-type $StorageType "
fi


echo "Executing Restore :" 
echo "$command"
echo ""
response=$($command)
command_status=$?

if [ "${command_status}" -gt "0" ]; then
        echo "API call  restore-db-instance-to-point-in-time returned exit code greater than zero. Command Failed."
        break
else
        echo "Restore is in progress."
fi

echo ""
sleep 5

if [ $PerformanceInsightsEnabled == 'true' ]
then
        com_enablepi="aws rds modify-db-instance --db-instance-identifier $TargetDBInstanceIdentifier --enable-performance-insights "
         if [ "$PerformanceInsightsRetentionPeriod" != 'null' ]
         then
             com_enablepi+="--performance-insights-retention-period $PerformanceInsightsRetentionPeriod "
        fi
        com_enablepi+="--performance-insights-kms-key-id $PerformanceInsightsKMSKeyId "
        echo "Enabling Performance Insights :"
        echo "$com_enablepi"
        echo ""
        response=$($com_enablepi)
fi

sleep 5 

if [ $MonitoringInterval != 0 ]
then
        com_enableem="aws rds modify-db-instance --db-instance-identifier $TargetDBInstanceIdentifier "
        com_enableem+="--monitoring-interval $MonitoringInterval "
        com_enableem+="--monitoring-role-arn $MonitoringRoleArn "
        echo "Enabling Enhanced Monirotring :"   
        echo "$com_enableem"
        echo ""
        response=$($com_enableem)
fi

sleep 5 

echo "Restore will take time. Script will end once the instance will be available."  
echo ""

aws rds wait db-instance-available --db-instance-identifier $TargetDBInstanceIdentifier 

result=$(aws rds describe-db-instances --db-instance-identifier $TargetDBInstanceIdentifier | jq '.DBInstances[0] .DBInstanceStatus')  
echo "Instance is now $result"

echo ""
echo "Script End."