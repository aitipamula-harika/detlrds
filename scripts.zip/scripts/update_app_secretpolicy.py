#!/usr/bin/env python3
"""
A script to change secrets policy 
"""
import boto3
import json
import datetime
import sys
import argparse
import time

PARSER = argparse.ArgumentParser()
# add a positional argument
PARSER.add_argument("ARN", help="ARN of secret")
# Add a rollback flag
PARSER.add_argument("-r", "--rollback", help="Rollback secret Policy",
                    action="store_true")

ARGV = PARSER.parse_args()


print("You entered secret ARN- ", ARGV.ARN)

#create secretsmanager boto3 client
client = boto3.client('secretsmanager')
ARN=ARGV.ARN



def rollback_policy(ARN):
    print("Please enter name of rollback policy file:")
    filename=input()
    print("Rollback initiated...")
    with open(filename, 'r') as outfile:
        policy=json.loads(outfile.read())
        
        #print(type(policy))
        if len(policy['Statement'])==0:
            respose = client.delete_resource_policy(SecretId=ARN)
        else:
            response = client.put_resource_policy(SecretId=ARN,ResourcePolicy=json.dumps(policy))
        time.sleep(2)
        print("Policy rollback Completed.")

if ARGV.rollback:
       rollback_policy(ARN)
else:
       print("Please choose right options. Run python3 update_secret.py -h for help!!!")
