#!/usr/bin/env python3
"""
A script to change secrets policy 
"""
import boto3
import json
import datetime
import sys
import argparse
import time

PARSER = argparse.ArgumentParser()
# add a positional argument
PARSER.add_argument("name", help="SecretName if updating policy/Policy file name if rollbacking policy")
# Add a update flag
PARSER.add_argument("-u", "--update", help="Update Secret Policy",
                    action="store_true")
# Add a rollback flag
PARSER.add_argument("-r", "--rollback", help="Rollback secret Policy",
                    action="store_true")
ARGV = PARSER.parse_args()


print("You entered secret name- ", ARGV.name)

#create secretsmanager boto3 client
client = boto3.client('secretsmanager')
secretname=ARGV.name
#Get secret ARN from secretname
res_descsecret=client.describe_secret(SecretId=secretname)
ARN=res_descsecret['ARN']


def rollback_policy(ARN):
    print("Please enter name of rollback policy file:")
    filename=input()
    print("Rollback initiated...")
    with open(filename, 'r') as outfile:
        policy=json.loads(outfile.read())
        
        #print(type(policy))
        if len(policy['Statement'])==0:
            respose = client.delete_resource_policy(SecretId=ARN)
        else:
            response = client.put_resource_policy(SecretId=ARN,ResourcePolicy=json.dumps(policy))
        time.sleep(2)
        print("Policy rollback Completed.")

def update_secret(ARN,secretname):
    print("Updating secret...")
    secretfilename=secretname.replace('/','_')
    #Get Account number
    accountno=boto3.client('sts').get_caller_identity()['Account']
    #Fetch existing policy
    policy=client.get_resource_policy(SecretId=ARN)
    if 'ResourcePolicy' in policy:
        policy=policy['ResourcePolicy'] 
    else:
        print("No Policy defined for this secret")
        policy={}
        policy['Version']="2012-10-17"
        policy['Statement']=[]
        policy=json.dumps(policy)
    
    #print(policy)
    #Take prechange backup of policy
    policy=json.loads(policy)
    pretimestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    with open("pre"+secretfilename+pretimestamp+".json", 'w') as outfile:
                        json.dump(policy, outfile,indent=4, sort_keys=True)

    #Add statements to policy
    statement1={"Effect" : "Allow","Principal" : {"AWS" : [ "arn:aws:iam::"+accountno+":role/DBAOperator", "arn:aws:iam::"+accountno+":role/DeveloperPowerUserProvisioner" ]},"Action" : [ "secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret", "secretsmanager:PutSecretValue", "secretsmanager:ListSecrets", "secretsmanager:TagResource", "secretsmanager:UntagResource", "secretsmanager:UpdateSecret", "secretsmanager:DeleteSecret" ]}
    policy['Statement'].append(statement1)
    policy['Statement'][-1]["Resource"]=ARN
    #print(policy)

    #Apply new policy
    response_policy=client.put_resource_policy(SecretId=ARN,ResourcePolicy=json.dumps(policy))
    #print(response_policy)
    time.sleep(2)
    print("Update Completed")
    #Take postchange backup of policy
    posttimestamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    with open("post"+secretfilename+posttimestamp+".json", 'w') as outfile:
        json.dump(policy, outfile,indent=4, sort_keys=True)


if ARGV.update:
       update_secret(ARN,secretname)
elif ARGV.rollback:
       rollback_policy(ARN)
else:
       print("Please choose right options. Run python3 update_secret.py -h for help!!!")
