#!/bin/bash
AWS_SECRET_NAME="ora-smtsrtssds-si-01-SDS-secret";
RDS_DB_ENDPOINT="your-endpoint-goes-here";
RDS_DB_USER="$(aws secretsmanager get-secret-value --secret-id $AWS_SECRET_NAME --query SecretString)"; # --output text| cut -d ',' -f1 | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//')";
RDS_DB_PASS="$(aws secretsmanager get-secret-value --secret-id $AWS_SECRET_NAME --query SecretString)"; # --output text| cut -d ',' -f2 | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"}$//')";
RDS_DB_NAME="your-database-name-goes here";

mysql -h $RDS_DB_ENDPOINT -u $RDS_DB_USER -p $RDS_DB_PASS -D $RDS_DB_NAME -e 'quit';

if [[ $? -eq 0 ]]; then
    echo "MySQL connection: OK";
else
    echo "MySQL connection: Fail";
fi;