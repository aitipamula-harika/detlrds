#!/bin/bash

LOGDIR=/var/log
LOGFILE=`basename $0`.log
echo "Pulling database secret from Secrets Manager" > $LOGDIR/$LOGFILE
export RDS_MYSQL_ENDPOINT="$(aws secretsmanager get-secret-value --output text --query SecretString --secret-id $1 --region $2 | python -c 'import json, sys; print(json.load(sys.stdin)["host"])')"
export RDS_MYSQL_USER="$(aws secretsmanager get-secret-value --output text --query SecretString --secret-id $1 --region $2 | python -c 'import json, sys; print(json.load(sys.stdin)["username"])')"
export RDS_MYSQL_PASS="$(aws secretsmanager get-secret-value --output text --query SecretString --secret-id $1 --region $2 | python -c 'import json, sys; print(json.load(sys.stdin)["password"])')"
export RDS_MYSQL_PORT="$(aws secretsmanager get-secret-value --output text --query SecretString --secret-id $1 --region $2 | python -c 'import json, sys; print(json.load(sys.stdin)["port"])')"
export RDS_MYSQL_DBNAME="$(aws secretsmanager get-secret-value --output text --query SecretString --secret-id $1 --region $2 | python -c 'import json, sys; print(json.load(sys.stdin)["dbname"])')"

if [[ $? -eq 0 ]]; then
    echo "Pulling secret completed successfully." >> $LOGDIR/$LOGFILE;
else
    echo "Error pulling secret. Please ensure that you have enough permissions to get secret value on $1." >> $LOGDIR/$LOGFILE;
fi

echo "Running job on $RDS_MYSQL_DBNAME from $3" >> $LOGDIR/$LOGFILE
mysql -h $RDS_MYSQL_ENDPOINT -u $RDS_MYSQL_USER -P $RDS_MYSQL_PORT -D $RDS_MYSQL_DBNAME --password=$RDS_MYSQL_PASS < $3;

if [[ $? -eq 0 ]]; then
    echo "All jobs completed successfully on $RDS_MYSQL_DBNAME" >> $LOGDIR/$LOGFILE;
else
    echo "Connection to database: Failed" >> $LOGDIR/$LOGFILE;
fi
