import boto3
import json
import sys
import getopt
import datetime
from difflib import Differ
import subprocess
import time


def main(argv):
    accountno = ""
    deployer = ""
    try:
        opts, args = getopt.getopt(
            argv, "ha:d:r:", ["help", "accno=", "deployer=", "rollback="]
        )
    except getopt.GetoptError:
        print("Invalid arguments!!!")
        print(
            "Update Policy Syntax : python3 modify_kms_policy.py -a <accountno> -d <Need deployer role ? yes/no>"
        )
        print("Rollback Policy Syntax : python3 modify_kms_policy.py -r <policy.json> ")
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-a", "--accno"):
            accountno = arg
        elif opt in ("-d", "--deployer"):
            deployer = arg
        elif opt in ("-r", "--rollback"):
            rollback = arg

    if len(opts) < 2:
        if opts[0][0] not in ("-h", "--help", "-r", "--rollbacki"):
            print("Invalid arguments!!!")
            print(
                "Update Policy Syntax : python3 modify_kms_policy.py -a <accountno> -d <Need deployer role ? yes/no>"
            )
            print(
                "Rollback Policy Syntax : python3 modify_kms_policy.py -r <policy.json> "
            )
            sys.exit()
        elif opts[0][0] in ("-r", "--rollback"):
            print("Policy file Name =", rollback)
            KMSClient = boto3.client("kms")
            response = KMSClient.describe_key(KeyId="alias/dms-shared-secret")
            KeyId = response["KeyMetadata"]["KeyId"]
            with open(rollback, "r") as outfile:
                response = KMSClient.put_key_policy(
                    KeyId=KeyId, PolicyName="default", Policy=outfile.read()
                )
                print("Policy rollback Complete.")
                sys.exit()
        else:
            print(
                "Update Policy Syntax : python3 modify_kms_policy.py -a <accountno> -d <Need deployer role ? yes/no>"
            )
            print(
                "Rollback Policy Syntax : python3 modify_kms_policy.py -r <policy.json> "
            )
            sys.exit()

    print("Account Number = ", accountno)
    print("Do you need deployer role ? =", deployer)

    # KMSClient = boto3.client('kms',
    #    aws_access_key_id='******',
    #    aws_secret_access_key='******',
    #    aws_session_token='********'
    # )

    KMSClient = boto3.client("kms")
    response = KMSClient.describe_key(KeyId="alias/dms-shared-secret")
    KeyId = response["KeyMetadata"]["KeyId"]
    policy = KMSClient.get_key_policy(KeyId=KeyId, PolicyName="default")["Policy"]
    policy = json.loads(policy)
    pretimestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    with open("prechange-policy" + pretimestamp + ".json", "w") as outfile:
        json.dump(policy, outfile, indent=4, sort_keys=True)
    for i in range(len(policy["Statement"])):
        if policy["Statement"][i]["Sid"] == "Allow use of the key by DMS role":
            policy["Statement"][i]["Principal"]["AWS"].append(
                "arn:aws:iam::" + accountno + ":role/dms-vpc-role"
            )
        if (
            "Allow use of the key by DeveloperPowerUserProvisioner"
            in policy["Statement"][i]["Sid"]
        ):
            policy["Statement"][i]["Principal"]["AWS"].append(
                "arn:aws:iam::" + accountno + ":role/DeveloperPowerUserProvisioner"
            )
            if deployer == "yes":
                policy["Statement"][i]["Principal"]["AWS"].append(
                    "arn:aws:iam::" + accountno + ":role/SpokeArtifactDeployer"
                )
    posttimestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    with open("postchange-policy" + posttimestamp + ".json", "w") as outfile:
        json.dump(policy, outfile, indent=4, sort_keys=True)
    try:
        time.sleep(3)
        response = KMSClient.put_key_policy(
            KeyId=KeyId, PolicyName="default", Policy=json.dumps(policy)
        )
        print(
            "Policy is updated. Please find difference between Pre and Post version of Policy."
        )
        time.sleep(2)
        process = subprocess.run(
            [
                "/usr/bin/diff",
                "prechange-policy" + pretimestamp + ".json",
                "postchange-policy" + posttimestamp + ".json",
            ],
            stdout=subprocess.PIPE,
            universal_newlines=True,
        )
        print(process.stdout)
    except Exception as inst:
        print(inst)


if __name__ == "__main__":
    main(sys.argv[1:])
