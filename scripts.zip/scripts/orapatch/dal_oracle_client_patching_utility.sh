#!/bin/ksh

#set -x

SCRIPTVER=0.15

export PSULEVEL=2021OCT

DAL_WHOAMI=`id -un`

unalias cp
unalias rm
unalias mv

export PATH=/repository/disdba/dbms/oracle/daldba/software/unzip:$PATH

echo 'Beginning Oracle Client Patching Utility Version '${SCRIPTVER}' at '`date`

echo '... Hostname is '`hostname`

# OS Prechecks

if [ `uname` = "Linux" ]; then
  echo '... Verified OS type is Linux'
  if [ `uname -i` = "x86_64" ]; then
    if [ -z $1 ]; then
      echo '<<FATAL>> Path to Oracle Client installation must be specified on command line'
      exit 3
    fi
    export WORKING_HOME=$1
    echo '... Verified OS bitlevel is 64 (x86-64)'
    DAL_LINUX_MAJOR_VERSION=0
    if [ -r /etc/os-release ]; then
      if [ `cat /etc/os-release | grep VERSION_ID | wc -l` -eq 1 ]; then
        DAL_LINUX_MAJOR_VERSION=`cat /etc/os-release | grep VERSION_ID | awk -F\= '{print $2}' | tr -d \" | awk -F\. '{print $1}'`
      else
        echo '<<WARNING>> Found /etc/os-release but file does not contain VERSION_ID parameter'
      fi
    fi
    if [ -r /etc/redhat-release ]; then 
      if [ ${DAL_LINUX_MAJOR_VERSION} -eq 0 ]; then
        if [ `cat /etc/redhat-release | grep 'Red Hat Enterprise Linux Server release 7' | wc -l` -eq 1 ]; then
          DAL_LINUX_MAJOR_VERSION=7
        elif [ `cat /etc/redhat-release | grep 'Red Hat Enterprise Linux Server release 6' | wc -l` -eq 1 ]; then
          DAL_LINUX_MAJOR_VERSION=6
        elif [ `cat /etc/redhat-release | grep 'Red Hat Enterprise Linux Server release 5' | wc -l` -eq 1 ]; then
          DAL_LINUX_MAJOR_VERSION=5
        elif [ `cat /etc/redhat-release | grep 'Red Hat Enterprise Linux Server release 8' | wc -l` -eq 1 ]; then
          DAL_LINUX_MAJOR_VERSION=8
        else
          echo '<<WARNING>> Found /etc/redhat-release but string does not match a known value'
        fi
      fi
    fi
  else
    echo '<<FATAL>> This script is only supported on 64-bit Linux OS'
    exit 2
  fi
else
  echo '<<FATAL>> This script is only supported for the Linux OS'
  exit 1
fi

echo '... Attempting to patch Oracle Client at '${WORKING_HOME}

# Oracle Prechecks

if [ -d ${WORKING_HOME} ]; then
  echo '...... Confirmed location is valid'
  export ORACLE_HOME=${WORKING_HOME}
  DAL_ORACLE_HOME_OWNER=`ls -dl ${ORACLE_HOME} | awk '{print $3}'`
  if [ ${DAL_ORACLE_HOME_OWNER} = ${DAL_WHOAMI} ]; then
    echo '...... Confirmed location is owned by currently connected user '${DAL_WHOAMI}
  else
    echo '<<FATAL>> Oracle Client location '${ORACLE_HOME}' is owned by '${DAL_ORACLE_HOME_OWNER}' but current user is '${DAL_WHOAMI}
    exit 4
  fi
  if [ -x ${ORACLE_HOME}/bin/sqlplus ]; then
    echo '...... Confirmed ORACLE_HOME contains executable binaries'
   # cd /repository/disdba/dbms/oracle/daldba/software/patches
    if [ -d /home/daldba ]; then
      echo '...... Confirmed patching repository is accessible from this host'
      if [ -x ${ORACLE_HOME}/OPatch/opatch ]; then
        echo '...... Confirmed OPatch executable is present in standard location'
        if [ -r ${ORACLE_HOME}/oraInst.loc ]; then
          echo '...... Confirmed Oracle Inventory pointer file is present in standard location'
          export DAL_ORAINST_LOC=`grep inventory_loc ${ORACLE_HOME}/oraInst.loc | awk -F\= '{print $2}' | tr -d '\r'`
          if [ -r ${DAL_ORAINST_LOC}/ContentsXML/inventory.xml ]; then
            echo '...... Confirmed Oracle Inventory XML repository exists and is accessible'
            export DAL_ORACLIENT_INSTALLED=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep 'Oracle Client' | wc -l`
            if [ ${DAL_ORACLIENT_INSTALLED} -eq 1 ]; then
              echo '...... Confirmed contents of ORACLE_HOME appear to be an Oracle Client installation'
              DAL_CLIENT_BITLEVEL=`file ${ORACLE_HOME}/bin/sqlplus | head -1 | awk '{print $3}'`
              if [ ${DAL_CLIENT_BITLEVEL} = "64-bit" ]; then
                export DAL_ORACLIENT_VER=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep 'Oracle Client' | awk '{print $4}'`
                case "${DAL_ORACLIENT_VER}" in
                  11.2.0.4.0) DAL_OPATCH_NUM=112000;DAL_DBVERNUM=11204;;
                  12.1.0.2.0) DAL_OPATCH_NUM=121010;DAL_DBVERNUM=12102;;
                  12.2.0.1.0) DAL_OPATCH_NUM=122010;DAL_DBVERNUM=12201;;
                  19.0.0.0.0) DAL_OPATCH_NUM=190000;DAL_DBVERNUM=19000;;
                  *) echo '<<FATAL>> Oracle Client version '${DAL_ORACLIENT_VER}' is not supported by this script'; exit 9
                esac 
                export PSULEVEL=`./dal_get_newest_releasever.ksh ${DAL_DBVERNUM}`
                echo '...... PSU Level Identified = '${PSULEVEL}'. Please make sure you have patches available for this PSULEVEL in S3 bucket s3://delta-rds-artifacts-us-east-1'
                export DAL_DBMS_PSUNUM=`grep ${PSULEVEL} ./autopatchlist | grep ${DAL_DBVERNUM} | grep DBONLYPSU | awk -F\: '{print $4}'`
		echo '...... DAL_DBMS_PSUNUM='${DAL_DBMS_PSUNUM}
                export DAL_JDK_PSUNUM=`grep ${PSULEVEL} ./autopatchlist | grep ${DAL_DBVERNUM} | grep JDKPSU | awk -F\: '{print $4}'`
		echo '...... DAL_JDK_PSUNUM='${DAL_JDK_PSUNUM}
                if [ ${DAL_DBVERNUM} -eq 19000 ]; then
                  export DAL_PERL_PSUNUM=0
                else
                  export DAL_PERL_PSUNUM=`grep ${PSULEVEL} ./autopatchlist | grep ${DAL_DBVERNUM} | grep PERLPSU | awk -F\: '{print $4}'`
		  echo '...... DAL_PERL_PSUNUM='${DAL_PERL_PSUNUM}
                fi
              else
                echo '<<FATAL>> This script only supports 64-bit Oracle Client installations; installed client at this location is '${DAL_CLIENT_BITLEVEL}
                exit 8
              fi
            else
              echo '<<FATAL>> Directory path at '${ORACLE_HOME}' does not seem to contain an Oracle Client'
              exit 7
            fi
          else
            echo '<<FATAL>> Oracle Inventory not present or incomplete at '${DAL_ORAINST_LOC}
            exit 6
          fi
        else
          echo '<<FATAL>> Oracle Inventory file '${ORACLE_HOME}'/oraInst.loc file missing or unavailable'
          exit 5
        fi
      else
        echo '<<FATAL>> OPatch executable not found at '${ORACLE_HOME}'/OPatch/opatch'
        exit 4
      fi
    else
      echo '<<FATAL>> Oracle Client patching repository under /repository not mounted or unavailable'
      exit 3
    fi
  else
    echo '<<FATAL>> Oracle Client installation not found at '${ORACLE_HOME}
    exit 2
  fi
else
  echo '<<FATAL>> Oracle Client path specified as '${WORKING_HOME}' appears invalid'
  exit 1
fi

# OS specific pre-check for 19c Client
if [ ${DAL_DBVERNUM} -eq 19000 ]; then
  if [ ${DAL_LINUX_MAJOR_VERSION} -lt 7 ]; then
    if [ ${DAL_LINUX_MAJOR_VERSION} -eq 0 ]; then
      echo '<<FATAL>> Oracle 19c Client requires Linux 7.x or higher, but could not determine OS version on this host'
      exit 1
    else
      echo '<<FATAL>> Oracle 19c Client is not supported on RHEL verion '${DAL_LINUX_MAJOR_VERSION}
      exit 1
    fi
  fi
fi

# Passed all pre-checks now update OPatch to latest version

echo '......... Oracle Client version detected is '${DAL_ORACLIENT_VER}
echo '......... Downloading Opatch patch from S3 bucket'
if [ -r /products/database/clients/oracle/patches/opatch/p6880880_${DAL_OPATCH_NUM}_Linux-x86-64.zip ]; then
  echo '......... No need to download. OPatch Patch p6880880_'${DAL_OPATCH_NUM}'_Linux-x86-64.zip exists on server already.'
else
  aws s3 cp "s3://delta-rds-artifacts-us-east-1/database/software-repository/oracle/opatch/p6880880_${DAL_OPATCH_NUM}_Linux-x86-64.zip" /products/database/clients/oracle/patches/opatch/
fi


DAL_OPATCH_LOC='/products/database/clients/oracle/patches/opatch/p6880880_'${DAL_OPATCH_NUM}'_Linux-x86-64.zip'

rm -f ${ORACLE_HOME}/p6880880.zip
cp ${DAL_OPATCH_LOC} ${ORACLE_HOME}/p6880880.zip
cd ${ORACLE_HOME}
unzip -qo p6880880.zip
RETVAL=$?
rm -f p6880880.zip

if [ ${RETVAL} -eq 0 ]; then
  echo '......... Successfully updated OPatch to latest version'
  echo '......... Downloading rdbms,jdk patches from S3 bucket'
  if [ -r /products/database/clients/oracle/patches/rdbms/lin64/${DAL_DBVERNUM}/PSU/${PSULEVEL}/ ]; then
      echo '......... No need to download rdbms patch. Patch '${DAL_DBMS_PSUNUM}'_'${DAL_DBVERNUM}'0_Linux-x86-64.zip exists on server already.'
  else	  
      aws s3 cp "s3://delta-rds-artifacts-us-east-1/database/software-repository/oracle/patches/rdbms/lin64/${DAL_DBVERNUM}/PSU/${PSULEVEL}/p${DAL_DBMS_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"  "/products/database/clients/oracle/patches/rdbms/lin64/${DAL_DBVERNUM}/PSU/${PSULEVEL}/"
  fi
  if [ -r /products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_JDK_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip ]; then
    echo '......... No need to download jdk patch. Patch '${DAL_JDK_PSUNUM}'_'${DAL_DBVERNUM}'0_Linux-x86-64.zip exists on server already.' 
  else
      aws s3 cp "s3://delta-rds-artifacts-us-east-1/database/software-repository/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_JDK_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"    "/products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/" 
  fi 
  
  DAL_DBMS_PSULOC='/products/database/clients/oracle/patches/rdbms/lin64/'${DAL_DBVERNUM}'/PSU/'${PSULEVEL}'/'${DAL_DBMS_PSUNUM}
  DAL_JDK_PSULOC='/products/database/clients/oracle/patches/jdk/lin64/'${DAL_DBVERNUM}'/'${PSULEVEL}'/'${DAL_JDK_PSUNUM}
  
  echo "......... Unzipping rdbms patch p${DAL_DBMS_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"
  unzip -qo "/products/database/clients/oracle/patches/rdbms/lin64/${DAL_DBVERNUM}/PSU/${PSULEVEL}/p${DAL_DBMS_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip" -d "/products/database/clients/oracle/patches/rdbms/lin64/${DAL_DBVERNUM}/PSU/${PSULEVEL}/"
  echo "......... Unzipped rdbms patch to location $DAL_DBMS_PSULOC"
  
  echo "......... Unzipping jdk patch p${DAL_JDK_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"
  unzip -qo "/products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_JDK_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip" -d "/products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/"
  echo "......... Unzipped jdk patch to location $DAL_JDK_PSULOC"
  	
  if [ $DAL_PERL_PSUNUM -ne 0 ];
  then
	 echo '........ Downloading Perl Patch'
         if [ -r /products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_PERL_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip ]; then
            echo '......... No need to download jdk patch. Patch '${DAL_PERL_PSUNUM}'_'${DAL_DBVERNUM}'0_Linux-x86-64.zip exists on server already.'
         else
 	     aws s3 cp "s3://delta-rds-artifacts-us-east-1/database/software-repository/oracle/patches/perl/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_PERL_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"  "/products/database/clients/oracle/patches/perl/lin64/${DAL_DBVERNUM}/${PSULEVEL}"
         fi
	 DAL_PERL_PSULOC='/products/database/clients/oracle/patches/perl/lin64/'${DAL_DBVERNUM}'/'${PSULEVEL}'/'${DAL_PERL_PSUNUM}
         echo "......... Unzipping jdk patch p${DAL_PERL_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip"
         unzip -qo "/products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/p${DAL_PERL_PSUNUM}_${DAL_DBVERNUM}0_Linux-x86-64.zip" -d "/products/database/clients/oracle/patches/jdk/lin64/${DAL_DBVERNUM}/${PSULEVEL}/"
         echo '......... Unzipped perl patch to location $DAL_PERL_PSUNUM'
 fi
else
  echo '<<FATAL>> Unable to update OPatch to current version; possible disk space issue'
  echo `df -h ${ORACLE_HOME}`
  exit 9
fi

echo '......... Working to apply PSU level '${PSULEVEL}

# First apply the DBMS PSU
# Confirm that the DBPSU is not already applied

DBMS_PSUINSTALLED=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep ${DAL_DBMS_PSUNUM} | wc -l`

if [ ${DBMS_PSUINSTALLED} -eq 0 ]; then

  # Special case for 11.2.0.4 needs additional patch applied BEFORE installing DB PSU
  if [ ${DAL_ORACLIENT_VER} = "11.2.0.4.0" ]; then
    DBPSU_11204_PREPATCH_LOC='/repository/disdba/dbms/oracle/daldba/software/patches/rdbms/lin64/'${DAL_DBVERNUM}'/one-off/'${PSULEVEL}'/24331924'
    DBPSU_11204_PREPATCH_INSTALLED=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep 24331924 | wc -l`
    if [ ${DBPSU_11204_PREPATCH_INSTALLED} -eq 0 ]; then
      if [ `${ORACLE_HOME}/OPatch/opatch prereq CheckSystemSpace -oh ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -ph ${DBPSU_11204_PREPATCH_LOC} 1>/dev/null 2>&1;RETVAL=$?;echo ${RETVAL}` -eq 0 ]; then
        ${ORACLE_HOME}/OPatch/opatch apply -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -silent -force ${DBPSU_11204_PREPATCH_LOC} 1>/dev/null 2>&1
        DBPSU_PREPATCH_RETVAL=$?
      else
        echo '<<FATAL>> Unable to apply patches due to insufficient disk space'
        exit 9
      fi
    else
      # Pre-patch is already installed
      DBPSU_PREPATCH_RETVAL=0
    fi
  else
    # No pre-patch needed for versions other than 11.2.0.4
    DBPSU_PREPATCH_RETVAL=0
  fi

  if [ ${DBPSU_PREPATCH_RETVAL} -eq 0 ]; then
    ${ORACLE_HOME}/OPatch/opatch prereq CheckSystemSpace -oh ${ORACLE_HOME} -ph ${DAL_DBMS_PSULOC} 1>/dev/null 2>&1
    CHECKSPACERETVAL=$?

    if [ ${CHECKSPACERETVAL} -eq 0 ]; then
      ${ORACLE_HOME}/OPatch/opatch apply -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -silent -force ${DAL_DBMS_PSULOC} 1>/dev/null 2>&1
      RETVAL=$?

      if [ ${RETVAL} -ne 0 ]; then
        echo '<<WARNING>> Unable to apply patchset update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
        echo '<<WARNING>> Attempting to proceed with JDK patches'
      else
        echo '......... Successfully applied DB patchset update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
      fi
    else
      echo '<<WARNING>> Unable to apply patchset update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation due to insufficient disk space'
      echo '<<WARNING>> Attempting to proceed with JDK patches'
    fi
  else
    echo '......... Skipping installation of DB patchset update due to 11.2.0.4 missing patch 24331924 and failed to install'
  fi
else
  echo '......... Found that DB patchset update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' has already been applied to Oracle Client installation'
fi

# Now apply the JDK patches

JDK_PSUINSTALLED=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep ${DAL_JDK_PSUNUM} | wc -l`

if [ ${JDK_PSUINSTALLED} -eq 0 ]; then
  if [ `${ORACLE_HOME}/OPatch/opatch prereq CheckSystemSpace -oh ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -ph ${DAL_JDK_PSULOC} 1>/dev/null 2>&1;RETVAL=$?;echo ${RETVAL}` -eq 0 ]; then
    ${ORACLE_HOME}/OPatch/opatch apply -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -silent -force ${DAL_JDK_PSULOC} 1>/dev/null 2>&1
    RETVAL=$?
  
    if [ ${RETVAL} -ne 0 ]; then
      echo '<<FATAL>> Unable to apply JDK update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
      exit 10
    else
      echo '......... Successfully applied JDK update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
    fi
  else
    echo '<<FATAL>> Unable to apply patches due to insufficient disk space'
    exit 9
  fi
else
  echo '......... Found that JDK update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' has already been applied to Oracle Client installation'
fi

# Finally apply the PERL patches
# In some cases PERL patches are not relevant, so check for a 0 value in DAL_PERL_PSUNUM

if [ ${DAL_PERL_PSUNUM} -ne 0 ]; then

  PERL_PSUINSTALLED=`${ORACLE_HOME}/OPatch/opatch lsinventory -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc | grep ${DAL_PERL_PSUNUM} | wc -l`

  if [ ${PERL_PSUINSTALLED} -eq 0 ]; then
    if [ `${ORACLE_HOME}/OPatch/opatch prereq CheckSystemSpace -oh ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -ph ${DAL_PERL_PSULOC} 1>/dev/null 2>&1;RETVAL=$?;echo ${RETVAL}` -eq 0 ]; then
      ${ORACLE_HOME}/OPatch/opatch apply -OH ${ORACLE_HOME} -invPtrLoc ${ORACLE_HOME}/oraInst.loc -silent -force ${DAL_PERL_PSULOC} 1>/dev/null 2>&1
      RETVAL=$?
  
      if [ ${RETVAL} -ne 0 ]; then
        echo '<<FATAL>> Unable to apply PERL update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
        exit 10
      else
        echo '......... Successfully applied PERL update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' to Oracle Client installation'
      fi
    else
      echo '<<FATAL>> Unable to apply patches due to insufficient disk space'
      exit 9
    fi
  else
    echo '......... Found that PERL update '${DAL_ORACLIENT_VER}' + '${PSULEVEL}' has already been applied to Oracle Client installation'
  fi
else
  echo '......... Found that there are no PERL updates to apply on this Oracle Client installation'
fi

# Any additional patches that need to be applied should go here

# Any other non-patch steps should go here

if [ ${DAL_DBVERNUM} -ne 19000 ]; then
  # The DB PSU for 19c Client handles this fix, and fails to apply if the directory has been removed
  echo '...... Removing any ORACLE_HOME/sqldeveloper subdirectories per CVE-2021-44228'
  rm -rf ${ORACLE_HOME}/sqldeveloper
fi

echo '...... Removing Unzipped Patch directories...'
rm -rf $DAL_DBMS_PSULOC
echo '...... RDBMS PATCH Directory Removed.'
rm -rf $DAL_JDK_PSULOC
echo '...... JDK PATCH Directory Removed.'
rm -rf $DAL_PERL_PSULOC
echo '...... PERL PATCH Directory Removed.'

echo 'Completed Oracle Client Patching Utility Version '${SCRIPTVER}' at '`date`

exit 0
