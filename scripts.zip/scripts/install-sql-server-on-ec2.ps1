# This is an ugly fix to prevent execution of this document before the IAM role change step executes
Start-Sleep -Seconds 90

# import AWSpowershell module

if(Get-Module AWSPowerShell){
	Remove-Module AWSPowerShell
}

Import-Module AWSPowerShell -ErrorAction Stop #Required

<#
    This function add current domain the the Domain Suffix list if not already.
    SQL Server setup requires this to validate Service account username/password.
#>
function AddDomainNameToDNSSuffixList{

    $DomainName = (Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem).Domain

    $SuffixSearchList = Get-DnsClientGlobalSetting | Select SuffixSearchList

    if ($DomainName -notin $SuffixSearchList.SuffixSearchList)
    {
        $SuffixSearchList.SuffixSearchList += $DomainName
        Set-DnsClientGlobalSetting -SuffixSearchList $SuffixSearchList.SuffixSearchList
    }

}

<#
    This function returns password for SQL SA user.
#>
function GetPasswordForSQLSAUser{

    param(

        $EnvironmentAbbriviation,
        $ApplicationBlockCode,
        $SAPasswordSecretKeyName

    )

    #$EnvironmentAbbriviation = "dvl"
    #$ApplicationBlockCode = "whatiscod4"

    $SAPasswordSecretKey = "${EnvironmentAbbriviation}-${ApplicationBlockCode}-${SAPasswordSecretKeyName}"
    
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "SA password not found in secrets manager. Stopping the installation"
        throw "SA password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString | ConvertFrom-Json
    
    $SQLSAPasswordPT = $null

    if ($SQLSAPasswordSS.username -eq "sa")
    {
        $SQLSAPasswordPT = $SQLSAPasswordSS.password
    }
    else
    {
        Write-Host "Username in the password payload is not sa. Stopping the installation."
        throw "Username in the password payload is not sa. Stopping the installation."
    }
    #Write-Host "SA Password $SQLSAPasswordPT"

    return ${SQLSAPasswordPT}

}

<#
    This function returns Credentials object for SQL SA user.
#>
function GetCredentialsObjectForSQLSAUser{

    param(

        $EnvironmentAbbriviation,
        $ApplicationBlockCode,
        $SAPasswordSecretKeyName

    )

    #$EnvironmentAbbriviation = "dvl"
    #$ApplicationBlockCode = "whatiscod4"
    #Write-Host "SA Password Secret Key is ${EnvironmentAbbriviation}/${ApplicationBlockCode}/SAPassword"

    $SAPasswordSecretKey = "${EnvironmentAbbriviation}-${ApplicationBlockCode}-${SAPasswordSecretKeyName}"
    
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "SA password not found in secrets manager. Stopping the installation"
        throw "SA password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString | ConvertFrom-Json
    
    $SQLSAPasswordPT = $null

    if ($SQLSAPasswordSS.username -eq "sa")
    {
        $SQLSAPasswordPT = $SQLSAPasswordSS.password
    }
    else
    {
        Write-Host "Username in the password payload is not sa. Stopping the installation."
        throw "Username in the password payload is not sa. Stopping the installation."
    }
    #Write-Host "SA Password $SQLSAPasswordPT"

    $SAPasswordAsStringPassword = ConvertTo-SecureString $SQLSAPasswordPT -AsPlainText -Force


    return New-Object System.Management.Automation.PSCredential ('sa', $SAPasswordAsStringPassword)


}


<#
    This function returns password for Service Account under which all SQL services will runAs
#>
function GetPasswordForSQLServiceAccount{


    $SAPasswordSecretKey = "sqlserverEC2SA-iimdbamsql-secret"
    $SAPasswordSecretFromSecretManager = Get-SECSecretValue -SecretId $SAPasswordSecretKey -ErrorAction SilentlyContinue

    if ($SAPasswordSecretFromSecretManager -eq $null)
    {
        Write-Host "Service Account password not found in secrets manager. Stopping the installation"
        throw "Service Account password not found in secrets manager. Stopping the installation"
    }


    $SQLSAPasswordSS = $SAPasswordSecretFromSecretManager.SecretString

    return $SQLSAPasswordSS

}

<#
    This function verifies that Service account is propertly setup on the machine.
    If the service account is not part of Administrator's group, it will be added.
#>
function VerifySQLServiceAccountSetup{

    
    $DomainName = (Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem).Domain
    
    $SQLServiceAccountUsernameFQ = "$DomainName\$SQLServiceAccountUsername".Trim()


    if ((Get-LocalGroupMember -Group "Administrators" -Member ${SQLServiceAccountUsernameFQ} -ErrorAction SilentlyContinue).Count -eq 0)
    {
        Write-Host "SQL Service Account $SQLServiceAccountUsername is not part of Administrators group. adding it"
        Add-LocalGroupMember -Group "Administrators" -Member $SQLServiceAccountUsernameFQ -ErrorAction SilentlyContinue
    }
    else
    {
        Write-Host "SQL Service Account $SQLServiceAccountUsername is already part of Administrators group."
    }

}


<#
    This function installs SQL Database engine and related feaures.
#>
function InstallSQLDatabaseEngine {

    # now lets unzip SQL PowerShell module
    $SQLPowerShellModuleFileOnLocal = Get-Item -Path $SQLPowerShellModuleDownloadFolderPathWithFileName
    Expand-Archive -Path $SQLPowerShellModuleFileOnLocal -DestinationPath $SQLPowerShellModuleExtractFolderPath -Force -ErrorAction SilentlyContinue
    
    #Importing SQL Server module as we need this later to run default database creation script
    Import-Module SqlServer
    
    $SQLSAUserPassword = GetPasswordForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

    $SQLServiceAccountUserPassword = GetPasswordForSQLServiceAccount

    $DomainName = (Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem).Domain


    # now lets unzip SQL set file
    $SQLSetupFileOnLocal = Get-Item -Path $SQLSetupDownloadFolderPathWithFileName
    $UnzipLocationOnLocal = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SQLSetupFileOnLocal.BaseName
    
    $SQLSetupConfigrationFileOnLocal = Join-Path $SQLSetupDownloadFolderPath -ChildPath $SQLServerSetupConfigurationFileNameOnLocal
    $ModifiedSQLSetupConfigrationFileOnLocal = Join-Path $SQLSetupDownloadFolderPath -ChildPath $ModifiedSQLServerSetupConfigurationFileNameOnLocal

    $DefaultDBCreationFileOnLocal = Join-Path $SQLSetupDownloadFolderPath -ChildPath $DefaultDatabaseCreationSQLScriptFileNameOnS3
    $ModifiedDBCreationFileOnLocal = Join-Path $SQLSetupDownloadFolderPath -ChildPath $ModifiedDefaultDatabaseCreationSQLScriptFileNameOnLocal

    if ($SQLSetupFileOnLocal.Extension -eq ".zip")
    {
        Write-Host "SQL Setup file $($SQLSetupFileOnLocal.FullName) is in the right format. Continuing with the installation"
        Expand-Archive -Path $SQLSetupFileOnLocal -DestinationPath $UnzipLocationOnLocal -Force
        $SQLSetupExeFilePath = Join-Path -Path $UnzipLocationOnLocal -ChildPath $SQLServerSetupFileNameOnLocal

        # now lets read Configuration.ini file
        $SetupConfigurationFileContent = Get-Content -Path $SQLSetupConfigrationFileOnLocal
    
        #Delete Modiied Config file if it exists

        Remove-Item -Path $ModifiedSQLSetupConfigrationFileOnLocal -ErrorAction SilentlyContinue

        # Now lets go thru each line in the Configuration file and replace the placeholders with the values supplied
        foreach ($line in $SetupConfigurationFileContent)
        {
            $line = $line -replace "<<SQLSERVERINSTANCENAME>>" , $SQLInstanceName

            $line = $line -replace "<<SQLSERVERINSTANCEID>>" , $SQLInstanceId

            $line = $line -replace "<<DomainName>>" , $DomainName

            $line = $line -replace "<<SQLServiceAccountUsername>>" , $SQLServiceAccountUsername

            $line = $line -replace "<<FeaturesToInstall>>" , ($FeaturesToInstall -join ",")
        
            $line = $line -replace "<<DistributedReplayControllerName>>" , $DistributedReplayControllerName

            $line = $line -replace "<<MaxSQLServerMemoryInMB>>" , $MaxSQLServerMemoryInMB

        
            Add-Content -Path $ModifiedSQLSetupConfigrationFileOnLocal -Value $line
        }

        #Delete Modiied default db creation sql script if it exists

        Remove-Item -Path $ModifiedDBCreationFileOnLocal -ErrorAction SilentlyContinue

        $DefaultDBCreationSQLFileContent = Get-Content -Path $DefaultDBCreationFileOnLocal
        
        $line = $null
        
        # Now lets go thru each line in Default database creation script and replace the Default database name with correct one
        foreach ($line in $DefaultDBCreationSQLFileContent)
        {
            $line = $line -replace "<<DEFAULTDATABASENAME>>" , $DefaultDatabaseName
        
            Add-Content -Path $ModifiedDBCreationFileOnLocal -Value $line
        }
        
        #This is very special as the setup complains about the controll directories not present.

        New-Item -ItemType Directory -Force -Path "E:\Program Files (x86)\Microsoft SQL Server\DReplayClient\WorkingDir"
        New-Item -ItemType Directory -Force -Path "E:\Program Files (x86)\Microsoft SQL Server\DReplayClient\ResultDir"

        
        # Now lets invoke SQL Setup with various passwords and specify configuration file
        Start-Process -FilePath "${SQLSetupExeFilePath}" -ArgumentList "/QUIET /IACCEPTSQLSERVERLICENSETERMS /IACCEPTROPENLICENSETERMS /IACCEPTPYTHONLICENSETERMS /ACTION=INSTALL /AGTSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /SQLSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /CLTSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /CTLRSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /SAPWD=`"${SQLSAUserPassword}`" /ISSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /ASSVCPASSWORD=`"${SQLServiceAccountUserPassword}`" /ConfigurationFile=`"${ModifiedSQLSetupConfigrationFileOnLocal}`"" -Wait

        # Now lets invoke default database creation script
        $SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

        # Alter sa login to disable enforce password policy

        Invoke-Sqlcmd -Query "USE MASTER; ALTER LOGIN [sa] WITH CHECK_POLICY = OFF;" -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

        #Execute default db creation file
        Invoke-Sqlcmd -InputFile $ModifiedDBCreationFileOnLocal -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

        #Now lets add log files to cloudwatch monitoring

        AddLogFilesToCWAgent

        SetupDBMailConfig

        SetupDefaultDBBackupJob

        #SetupMonitoringAsWindowsTasks




    }
    else
    {
        Write-Host "SQL Setup file $($SQLSetupFileOnLocal.FullName) is not in the right format. Expected a zip file. Stopping installation"
        throw "SQL Setup file $($SQLSetupFileOnLocal.FullName) is not in the right format. Expected a zip file. Stopping installation"
    }

}

function SetupDBMailConfig{

    Write-Host "Setting up DB Mail Config"


    $DBMailScripts = Get-ChildItem $DBMailSetupScriptsLocalFolderPath

    # Now lets invoke default database backup job creation script
    $SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

    foreach ($MailSetupScript in $DBMailScripts)
    {
        $ModifiedScriptName = "Modified$(${MailSetupScript}.Name)"
        $ModifiedScriptPath = Join-Path $DBMailSetupScriptsLocalFolderPath -ChildPath $ModifiedScriptName
        Write-Host $ModifiedScriptName
        Write-Host $ModifiedScriptPath
        Remove-Item -Path $ModifiedScriptPath -ErrorAction SilentlyContinue

        $ScriptFileContent = Get-Content -Path $MailSetupScript.FullName

        $line = $null
        
        # Now lets go thru each line in Default database creation script and replace the Default database name with correct one
        foreach ($line in $ScriptFileContent)
        {
            $line = $line -replace "<<DatabaseName>>" , $DefaultDatabaseName
        
            Add-Content -Path $ModifiedScriptPath -Value $line
        }

        Invoke-Sqlcmd -InputFile $ModifiedScriptPath -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

    }
    
}

function SetupDefaultDBBackupJob{

    Write-Host "Setting up default database backup job"


    $DBBackupScripts = Get-ChildItem $BackupScriptsLocalFolderPath

    # Now lets invoke default database backup job creation script
    $SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

    foreach ($BackupScript in $DBBackupScripts)
    {
        $ModifiedScriptName = "Modified$(${BackupScript}.Name)"
        $ModifiedScriptPath = Join-Path $BackupScriptsLocalFolderPath -ChildPath $ModifiedScriptName
        Write-Host $ModifiedScriptName
        Write-Host $ModifiedScriptPath
        Remove-Item -Path $ModifiedScriptPath -ErrorAction SilentlyContinue

        $ScriptFileContent = Get-Content -Path $BackupScript.FullName

        $line = $null
        
        # Now lets go thru each line in Default database creation script and replace the Default database name with correct one
        foreach ($line in $ScriptFileContent)
        {
            $line = $line -replace "<<DatabaseName>>" , $DefaultDatabaseName
        
            Add-Content -Path $ModifiedScriptPath -Value $line
        }

        Invoke-Sqlcmd -InputFile $ModifiedScriptPath -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject

    }
    
}

function SetupMonitoringAsWindowsTasks{
    
    Write-Host "Setting up Monitoring scripts"

    $MonitoringScripts = Get-ChildItem $MonitoringScriptsLocalFolderPath
    
    foreach ($monitoringScript in $MonitoringScripts)
    {
        
        $TaskName = "$($monitoringScript.Name)"
        $ScriptToRun = "$($monitoringScript.FullName)"
        $RepeatAfterMinutes = (New-TimeSpan -Minutes 5)

        $trigger = New-JobTrigger -Once -At (Get-Date).AddMinutes(5) -RepeatIndefinitely -RepetitionInterval $RepeatAfterMinutes

        $action = New-ScheduledTaskAction  -Execute 'Powershell.exe' -Argument "-File `"${ScriptToRun}`" "

        $principal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount 


        Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "$TaskName" -Description "SQL Monitoring Script" -Principal $principal 

    }



}

function AddLogFilesToCWAgent{

        #Now lets get the error log and agent log file locations and add them to cloudwatch monitoring
        Write-Host "Adding Log files to CW Agent Config"

        $SACredObject = GetCredentialsObjectForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

        $ErrorLogLocation = Invoke-Sqlcmd -Query "SELECT SERVERPROPERTY('ErrorLogFileName') AS 'ErrorLogFileLocation'" -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject 

        $AgentLogLocation = Invoke-Sqlcmd -Query "EXEC msdb.dbo.sp_get_sqlagent_properties" -ServerInstance "$env:COMPUTERNAME" -Credential $SACredObject 

        # Now Lets read CloudWatch Agent Configuration file and ask it to collect SQL Error Log file and send it to CloudWatch Log Group
        $CLoudWatchConfigFileLocation = "C:\ProgramData\Amazon\AmazonCloudWatchAgent\Configs\file_amazon-cloudwatch-os-windows-configuration.json"

        $SQLErrorFileCloudWatchLogGroupName = "/aws/mssqlonec2/$($ApplicationBlockCodeParam.ParameterValue)/$($NameTag.Value)/$SQLInstanceName/error"
        $SQLAgentFileCloudWatchLogGroupName = "/aws/mssqlonec2/$($ApplicationBlockCodeParam.ParameterValue)/$($NameTag.Value)/$SQLInstanceName/agent"

        $CLoudWatchConfigFileContent = Get-Content $CLoudWatchConfigFileLocation | ConvertFrom-Json

        # Now lets create the necessary JSON schema if not already there
        if($CLoudWatchConfigFileContent.logs.logs_collected -notmatch "files")
        {
            $files = [PSCustomObject]@{}
            $CLoudWatchConfigFileContent.logs.logs_collected | Add-Member -Name "files" -MemberType NoteProperty -Value $files
        }

        if($CLoudWatchConfigFileContent.logs.logs_collected.files -notmatch "collect_list")
        {
            $collect_list = [PSCustomObject]@()
            $CLoudWatchConfigFileContent.logs.logs_collected.files | Add-Member -Name "collect_list" -MemberType NoteProperty -Value $collect_list
        }

        $SQLErrorLogConFig = [PSCustomObject]@{
                    "file_path" = "$($ErrorLogLocation.ErrorLogFileLocation)"
					"log_group_name" = "$SQLErrorFileCloudWatchLogGroupName"
					"log_stream_name" = "{instance_id}"
					"timezone" = "UTC"
					"timestamp_format" = "yyyy-MM-dd HH:mm:ss"
					"encoding" = "UTF-16"

            }

        $CLoudWatchConfigFileContent.logs.logs_collected.files.collect_list += $SQLErrorLogConFig

        # now add agent log file to cloudwatch agent

        $SQLAgentLogConFig = [PSCustomObject]@{
                    "file_path" = "$($AgentLogLocation.errorlog_file)"
					"log_group_name" = "$SQLAgentFileCloudWatchLogGroupName"
					"log_stream_name" = "{instance_id}"
					"timezone" = "UTC"
					"timestamp_format" = "yyyy-MM-dd HH:mm:ss"
					"encoding" = "UTF-16"

            }

        $CLoudWatchConfigFileContent.logs.logs_collected.files.collect_list += $SQLAgentLogConFig

<#


        # Now lets create the necessary JSON schema for procstat if not already there
        if($CLoudWatchConfigFileContent.metrics.metrics_collected  -notmatch "procstat")
        {
            $procstat = [PSCustomObject]@()
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "procstat" -MemberType NoteProperty -Value $procstat
        }

        $SQLProcStatMonitoring = [PSCustomObject]@{
                "exe" = "sqlservr"
				"measurement" = @("cpu_usage","memory_rss","memory_vms","read_bytes","write_bytes","read_count","write_count")

        }

        $CLoudWatchConfigFileContent.metrics.metrics_collected.procstat += $SQLProcStatMonitoring


        #let add sql server access method monitoring
        
        $SQLAccessMethodMonitoring = [PSCustomObject]@{
                    "measurement" = @("Page Splits/sec", "Forwarded Records/sec", "Full scans/sec")				

        }
        
        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "SQLServer:Access Methods")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.'SQLServer:Access Methods' = $SQLAccessMethodMonitoring
        }
        else
        {
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "SQLServer:Access Methods" -MemberType NoteProperty -Value $SQLAccessMethodMonitoring
        }

        #let add sql server buffer manager monitoring
        $SQLBufferManagerMonitoring = [PSCustomObject]@{
                    "measurement" = @("Page Life Expectancy", "Lazy Writes/Sec", "Checkpoint Pages/Sec","Page reads/sec","Page writes/sec","Free pages","Stolen pages","Buffer Cache hit ratio","Target Server Memory(KB)","Total Server Memory(KB)")				

        }
        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "SQLServer:Buffer Manager")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.'SQLServer:Buffer Manager' = $SQLBufferManagerMonitoring
        }
        else
        {

            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "SQLServer:Buffer Manager" -MemberType NoteProperty -Value $SQLBufferManagerMonitoring
        }

        #let add SQL Server General Statistics monitoring
        $SQLServerGeneralStatisticsMonitoring = [PSCustomObject]@{
                    "measurement" = @("User Connections", "Logins/sec","Logouts/sec")				

        }

        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "SQLServer:General Statistics")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.'SQLServer:General Statistics' = $SQLServerGeneralStatisticsMonitoring
        }
        else
        {
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "SQLServer:General Statistics" -MemberType NoteProperty -Value $SQLServerGeneralStatisticsMonitoring 
        }

        #let add SQL Server Process monitoring
        $SQLProcessMonitoring = [PSCustomObject]@{
                    "measurement" = @("Pool Paged Bytes", "% Processor Time", "Private Bytes", "Thread Count")
                    "resources" = @("sqlservr")				

        }

        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "Process")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.Process = $SQLProcessMonitoring
        }
        else
        {
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "Process" -MemberType NoteProperty -Value $SQLProcessMonitoring 
        }

        #let add SQL Server SQL Statistics monitoring
        $SQLServerSQLStatisticsMonitoring = [PSCustomObject]@{
                    "measurement" = @("SQL Compilations/sec", "SQL Re-Compilations/sec")				

        }

        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "SQLServer:SQL Statistics")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.'SQLServer:SQL Statistics' = $SQLServerSQLStatisticsMonitoring
        }
        else
        {
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "SQLServer:SQL Statistics" -MemberType NoteProperty -Value $SQLServerSQLStatisticsMonitoring 
        }

        #let add SQL Server Latches monitoring
        $SQLServerLatchesMonitoring = [PSCustomObject]@{
                    "measurement" = @("Latch Waits/sec", "Average Latch Wait Time (ms)", "Average Latch Wait Time Base", "Total Latch Wait Time (ms)", "Number of SuperLatches", "SuperLatch Promotions/sec", "SuperLatch Demotions/sec")				

        }

        if ($CLoudWatchConfigFileContent.metrics.metrics_collected -match "SQLServer:Latches")
        {
            
            $CLoudWatchConfigFileContent.metrics.metrics_collected.'SQLServer:Latches' = $SQLServerLatchesMonitoring
        }
        else
        {
            $CLoudWatchConfigFileContent.metrics.metrics_collected | Add-Member -Name "SQLServer:Latches" -MemberType NoteProperty -Value $SQLServerLatchesMonitoring 
        }

        #>
        # now lets put the new config in the CloudWatch agent config file

        Set-Content -Value (ConvertTo-Json $CLoudWatchConfigFileContent -Depth 100 ) -Path $CLoudWatchConfigFileLocation

        
        # now lets restart CloudWatch Agent service

        Restart-Service -Name AmazonCloudWatchAgent -Force

}

<#
    This function installs SSRS
#>
function InstallSQLServerReportingServices{
        
        

        $SSRSInstallPath = "E:\Program Files\Microsoft SQL Server Reporting Services"
        $ProductKeySS = (Get-SECSecretValue -SecretId $SQLServerProductKeyName).SecretString
        Start-Process "${SSRSSetupDownloadFolderPathWithFileName}" -ArgumentList "/IAcceptLicenseTerms /Quiet /Norestart /PID=${ProductKeySS} /InstallFolder=`"$SSRSInstallPath`"" -Wait 
}

<#
    This function installs SSMS
#>
function InstallSQLServerManagementStudio{

        
        
        $SSMSInstallPath = "E:\Program Files (x86)\Microsoft SQL Server Management Studio 18"
        #Start-Process "$SSMSSetupDownloadFolderPathWithFileName" -ArgumentList "SSMSInstallRoot=`"$SSMSInstallPath`" /Install /Quiet /Norestart" -Wait
        Start-Process "${SSMSSetupDownloadFolderPathWithFileName}" -ArgumentList "SSMSInstallRoot=`"${SSMSInstallPath}`" /Install /Quiet /Norestart" -Wait

}

$CloudFormationStackNameTagKey = "aws:cloudformation:stack-name"
$DBEngineParamKey = "dbEngine"
$SQLDriveLetterStandards = @("E","F","G","H","I")
$DBEngineFeatures = @("SQLENGINE","REPLICATION","FULLTEXT","DQ","DQC","CONN","IS","DREPLAY_CTLR","DREPLAY_CLT","MDS")
$SSASFeatures = @("AS")
#$SSRSFeatures = @("RS")

$SQLInstanceName="MSSQLSERVER"
$SQLInstanceNumber = "01"
$SQLInstanceNumber = $SQLInstanceNumber.PadLeft(2,'0')
$DefaultDatabaseNumber = "01"
$SQLInstanceId="$SQLInstanceName$SQLInstanceNumber"
$DistributedReplayControllerName=""
$InstallDatabaseEngine = "Yes"
$InstallAnalysisService = "Yes"
$InstallReportingServices = "Yes"
$InstallSQLServerManagementStudio = "Yes"

#$SQLServerProductKeyPrefix = "SQL2019StdEd"

$S3BucketNameForSQLServerRelatedArtifacts = "delta-postcfg-artifacts-us-east-1" # {"ParamInfo":{"Name":"S3BucketNameForSQLServerRelatedArtifacts","Type":"String","Description":"S3 Bucket Name For SQL Server Setup Related Artifacts", "Default": "delta-postcfg-artifacts-us-east-1"}}

$S3KeyLocationForSQLServerSetupFile = "database/software-repository/SqlServer" 
#$SQLServerSetupFileNameOnS3 = "SQL2019StdEd.zip"
$SQLServerSetupFileNameOnLocal = "setup.exe"

$S3KeyLocationForSQLServerPowerShellModuleFile = "database/software-repository/SqlServer"
$SQLServerPowerShellModuleFileNameOnS3 = "powershell-module-sqlserver.zip"
$SQLServerPowerShellModuleExtractFolderNameOnLocal = "SqlServer"

$S3KeyLocationForSQLServerSetupConfigurationFile = "database/software-repository/SqlServer"
$SQLServerSetupConfigurationFileNameOnS3 = "SQL-2019-ConfigurationFile.ini"
$SQLServerSetupConfigurationFileNameOnLocal = "ConfigurationFile.ini"
$ModifiedSQLServerSetupConfigurationFileNameOnLocal = "ModifiedConfigurationFile.ini"

$S3KeyLocationForDefaultDatabaseCreationSQLScriptFile = "database/software-repository/SqlServer"
$DefaultDatabaseCreationSQLScriptFileNameOnS3 = "mssql_db_create.sql"
$ModifiedDefaultDatabaseCreationSQLScriptFileNameOnLocal = "modified_mssql_db_create.sql"

$S3KeyLocationForSSRSSetupFile = "database/software-repository/SqlServer"
$SSRSSetupFileNameOnS3 = "SQLServerReportingServices_2019.exe"

$S3KeyLocationForSSMSSetupFile = "database/software-repository/SqlServer"
$SSMSSetupFileNameOnS3 = "SSMS-Setup-ENU-1810.exe"

$S3KeyLocationForMonitoringScripts = "database/scripts/mssql-on-ec2-scripts/monitoring-scripts/current/"
$MonitoringScriptstFolderNameOnLocal = "monitoring-scripts"

$S3KeyLocationForBackupScripts = "database/scripts/mssql-on-ec2-scripts/backup-scripts/current/"
$BackupScriptstFolderNameOnLocal = "backup-scripts"

$S3KeyLocationForDBMailSetupScripts = "database/scripts/mssql-on-ec2-scripts/db-mail-config-scripts/current/"
$DBMailSetupScriptstFolderNameOnLocal = "dbmail-setup-scripts"

$SQLServiceAccountUsername = "svciimdbamsql" # do not parameterize this.

#$SQLServerProductKeyName = "$SQLServerProductKeyPrefix-Key"

# Lets get the CFT that created this instance and read all the parameters

$EC2InstanceId = Get-EC2InstanceMetadata -Category InstanceId

$EC2Tags = (Get-EC2Tag -Filter @{Name="resource-type";Values="instance"},@{Name="resource-id";Values=$EC2InstanceId}) | Select-Object Key, Value

# If for some reason, we did not get the tags, exit the automatin
if ($EC2Tags -eq $null)
{
    Write-Host "Unable to obtain tags for EC2 instance $EC2InstanceId. Stopping the installation"
    throw "Unable to obtain tags for EC2 instance $EC2InstanceId. Stopping the installation"
    #Exit
}

Write-Host "tags obtained for EC2 instance $EC2InstanceId. Continuing with the installation"

# Now lets read the tag to obtain cloudformation stack name

$CFTStackNameTag = $EC2Tags | ?{ $_.Key -eq "$CloudFormationStackNameTagKey" }

if ($CFTStackNameTag -eq $null)
{
    Write-Host "Unable to obtain CloudFormation Stack Name tag from Tags for EC2 instance $EC2InstanceId. Stopping the installation"
    throw "Unable to obtain CloudFormation Stack Name tag from Tags for EC2 instance $EC2InstanceId. Stopping the installation"

}

Write-Host "Found CloudFormation Stack Name tag from Tags for EC2 instance $EC2InstanceId. Continuing with the installation"

# Now lets read all the parameters provided to the CFT

$CFNStack = Get-CFNStack -StackName $CFTStackNameTag.Value

# before we go any further, lets make sure dbengine param is set correctly and if not exit the automation.
$DBEngineParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq $DBEngineParamKey} | select ParameterValue

Switch ($DBEngineParam.ParameterValue)
{
    "dbserver-sql2019std"
    {
        Write-Host "SQL Server 2019 Standard Edition is selected"
        Write-Host "dbEngine param value is $($DBEngineParam.ParameterValue) and it is valid. Continuing with the installation."
        $SQLServerProductKeyPrefix = "SQL2019StdEd"
        $SQLServerProductKeyName = "$SQLServerProductKeyPrefix-Key"
        $SQLServerSetupFileNameOnS3 = "SQL2019StdEd.zip"
    }
    "dbserver-sql2019ee"
    {
        Write-Host "SQL Server 2019 Enterprise Edition is selected"
        Write-Host "dbEngine param value is $($DBEngineParam.ParameterValue) and it is valid. Continuing with the installation."
        $SQLServerProductKeyPrefix = "SQL2019EntEd"
        $SQLServerProductKeyName = "$SQLServerProductKeyPrefix-Key"
        $SQLServerSetupFileNameOnS3 = "SQL2019EntEd.zip"
    }

    default
    {
        Write-Host "dbEngine param value is not valid. stopping the installation."
        throw "dbEngine param value is not valid. stopping the installation."

        #Exit

    }
}

<#
#now based on the db engine param, set file names
switch ($DBEngineParam.ParameterValue){
    "dbserver-sql2019std"
    {
        Write-Host "SQL Server 2019 Standard Edition is selected"
        $SQLServerProductKeyPrefix = "SQL2019StdEd"
        $SQLServerProductKeyName = "$SQLServerProductKeyPrefix-Key"
        $SQLServerSetupFileNameOnS3 = "SQL2019StdEd.zip"
    }
    "dbserver-sql2019ee"
    {
        Write-Host "SQL Server 2019 Enterprise Edition is selected"
        $SQLServerProductKeyPrefix = "SQL2019EntEd"
        $SQLServerProductKeyName = "$SQLServerProductKeyPrefix-Key"
        $SQLServerSetupFileNameOnS3 = "SQL2019EntEd.zip"
    }
    Default
    {
        Write-Host "Unknown db engine param . Stopping the installation"
        throw "Unknown db engine param. Stopping the installation"
    }
}
#>

# Now that we are certain that we need to install SQL Server on this EC2. Lets make sure drives letters are as per the stanadrd and format them with 64 kb block size if required.

$AllDrivesExceptBootDrive = Get-Volume | Where-Object {$_.DriveLetter -ne 'C'} | Select-Object DriveLetter, FileSystemLabel, AllocationUnitSize

$StandardDrivesThatAreNotPresent = $SQLDriveLetterStandards |Where-Object {$_ -notin $AllDrivesExceptBootDrive.DriveLetter}


if ($StandardDrivesThatAreNotPresent.Count -gt  0)
{
    Write-Host "Drive letters on this EC2 are not as per SQL Standard. Missing drive letters $($StandardDrivesThatAreNotPresent -join ","). Stopping the installation"
    throw "Drive letters on this EC2 are not as per SQL Standard. Missing drive letters $($StandardDrivesThatAreNotPresent -join ","). Stopping the installation"   
}

Write-Host "All drive letters on this EC2 are as per SQL Standard. Continuing with the installation"


#$DriveLetters = ${AllDrivesExceptBootDrive} | ForEach-Object -Process {$_.DriveLetter+':'}

foreach ($d in $AllDrivesExceptBootDrive)
{
    #Write-Host "Checking Drive $($d.DriveLetter):"
    $TempDriveLetter = "$($d.DriveLetter):"
    if((Get-ChildItem -Path $TempDriveLetter).Count -eq 0)
    {
        Write-Host "Drive $TempDriveLetter is empty. Checking for Allocation Unit Size"
        if ($d.AllocationUnitSize -ne 65536)
        {
            Write-Host "Drive $TempDriveLetter does not have 64kb Allocation Unit Size. Formatting it to make it 64kb Allocation Unit Size"
            Format-Volume -DriveLetter $d.DriveLetter -FileSystem NTFS -AllocationUnitSize 65536
        }
        else
        {
            Write-Host "Drive $TempDriveLetter has 64kb Allocation Unit Size. Skip Formatting the drive"
        }
    }
    else
    {
        Write-Host "Drive $TempDriveLetter is not empty. Skip checking for Allocation Unit Size"
    }   
}

Write-Host "Drive letter and allocation unit size check completed. Continuing with the installation"

# grab applicationBlockCode Param from CFT
$ApplicationBlockCodeParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "applicationBlockCode"} | select ParameterValue

if ($ApplicationBlockCodeParam -eq $null)
{
    Write-Host "CFT stack does not have Application Block Code parameter defined. Stopping the installation"
    throw "CFT stack does not have Application Block Code parameter defined. Stopping the installation"
}

Write-Host "Application Block Code parameter value is $($ApplicationBlockCodeParam.ParameterValue). Continuing with the installation"


# grab Environment Tag from EC2
$EnvironmentTag = $EC2Tags | ?{ $_.Key -eq "Environment" }

if ($EnvironmentTag -eq $null)
{
    Write-Host "EC2 does not have Environment tag defined. Stopping the installation"
    throw "EC2 does not have Environment tag defined. Stopping the installation"
}

Write-Host "Environment tag value is $($EnvironmentTag.Value). Continuing with the installation"

# grab Name Tag from EC2
$NameTag = $EC2Tags | ?{ $_.Key -eq "Name" }

if ($NameTag -eq $null)
{
    Write-Host "EC2 does not have Name tag defined. Stopping the installation"
    throw "EC2 does not have Name tag defined. Stopping the installation"
}

Write-Host "Name tag value is $($NameTag.Value). Continuing with the installation"


# grab SAPassword Secret Name Param from CFT
$SAPasswordSecretKeyNameParam = $CFNStack.Parameters | ?{ $_.ParameterKey -eq "SAPasswordSecretName"} | select ParameterValue

if ($SAPasswordSecretKeyNameParam -eq $null)
{
    Write-Host "CFT stack does not have SAPasswordSecretName parameter defined. Stopping the installation"
    throw "CFT stack does not have SAPasswordSecretName parameter defined. Stopping the installation"
}

Write-Host "SAPasswordSecretName parameter value is $($SAPasswordSecretKeyNameParam.ParameterValue). Continuing with the installation"

#----

Write-Host "Validating DNS suffix list"

AddDomainNameToDNSSuffixList

$DefaultDatabaseName = "sql_$($ApplicationBlockCodeParam.ParameterValue.ToLower())_$($EnvironmentTag.Value)01_$DefaultDatabaseNumber"

$SQLSAUserPassword = GetPasswordForSQLSAUser -EnvironmentAbbriviation $EnvironmentTag.Value -ApplicationBlockCode $ApplicationBlockCodeParam.ParameterValue -SAPasswordSecretKeyName $SAPasswordSecretKeyNameParam.ParameterValue

Write-Host "SA password found in secrets manager. Continuing with the installation"

$SQLServiceAccountUserPassword = GetPasswordForSQLServiceAccount 

Write-Host "Service Account password found in secrets manager. Continuing with the installation"

# Verify Service Account is part of Administrators Group. If not, add it
VerifySQLServiceAccountSetup

# Temp. Delete after getting service account details
#$LocalSAAccountUsername = "svc$($ApplicationBlockCodeParam.ParameterValue.ToLower())sql"


$FeaturesToInstall = @()
$FeaturesToInstallInfo = @()

if ($InstallDatabaseEngine -eq "Yes")
{
    $FeaturesToInstall += $DBEngineFeatures -join ","
    $FeaturesToInstallInfo += "Database Engine"
}

if ($InstallAnalysisService -eq "Yes")
{
    $FeaturesToInstall += $SSASFeatures -join ","
    $FeaturesToInstallInfo += "SQL Server Analysis Services"
}

if ($InstallReportingServices -eq "Yes")
{
    #$FeaturesToInstall += $SSRSFeatures -join ","
    $FeaturesToInstallInfo += "SQL Server Reporting Services"
}

if ($InstallSQLServerManagementStudio -eq "Yes")
{
    $FeaturesToInstallInfo += "SQL Server Management Studio"
}


if ($InstallDatabaseEngine -eq "No" -and $InstallAnalysisService -eq "No" -and $InstallReportingServices -eq "No" -and $InstallSQLServerManagementStudio -eq "No"  )
{
    Write-Host "No features are selected to install. Stopping the installation"
    throw "No features are selected to install. Stopping the installation"
}

Write-Host "SQL features $($FeaturesToInstallInfo -join ", ") will be installed"

# now lets do memory calculation.
<#
    Formula to calculate Memory is taken from the best practices document at: https://docs.aws.amazon.com/prescriptive-guidance/latest/sql-server-ec2-best-practices/sql-server-ec2-best-practices.pdf
    Formula: max_server_memory = total_RAM – (1 GB for the OS + memory_basis_amount_of_RAM_on_the_server)
    memory basis amount of RAM is determined as follows:
        • If RAM on the server is between 4 GB and 16 GB, leave 1 GB per 4 GB of RAM. 
            Example, for a server with 16 GB, leave 4 GB.
        • If RAM on the server is over 16 GB, leave 1 GB per 4 GB of RAM up to 16 GB, and 1 GB per 8 GB of RAM above 16 GB.
            Example, if a server has 256 GB of RAM, the calculation will be:
                • 1 GB for the OS
                • Up to 16 GB RAM: 16/4 = 4 GB
                • Remaining RAM above 16 GB: (256-16)/8 = 30
                • Total RAM to leave: 1 + 4 + 30 = 35 GB
                • max_server_memory: 256 - 35 = 221 GB

#>

$TotalRAMInGB = (Get-CimInstance -ClassName Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum /1Gb
$ReserveMemoryForOSInGB = 1
$MaxSQLServerMemoryInMB = $null

if (($TotalRAMInGB) -in 4..16)
{
    Write-Host "Memory is between 4 and 16 Gb."
    $ReservedMemoryBasisAmountInGB = $TotalRAMInGB/4
    $MaxSQLServerMemoryInMB = (($TotalRAMInGB - ($ReserveMemoryForOSInGB + $ReservedMemoryBasisAmountInGB)) *1Mb)/1Kb
}

elseif (($TotalRAMInGB/1Gb) -gt 16)

{
    Write-Host "Memory is above 16 Gb."
    $ReservedMemoryBasisAmountUpto16GBInGB = 16/4
    $ReservedMemoryForRemainingMemoryAbove16GB = ($TotalRAMInGB-16)/8
    $TotalMemoryToLeave = $ReserveMemoryForOSInGB + $ReservedMemoryBasisAmountUpto16GBInGB + $ReservedMemoryForRemainingMemoryAbove16GB
    $MaxSQLServerMemoryInMB = (($TotalRAMInGB - $TotalMemoryToLeave) * 1Mb)/1Kb

}
else
{
    Write-Host "Memory is less than 4 Gb."
    $MaxSQLServerMemoryInMB = (($TotalRAMInGB - $ReserveMemoryForOSInGB) *1Mb)/1Kb

}

    Write-Host "MAX memonry reserved for SQL Server will be $MaxSQLServerMemoryInMB Mb"


$TempDir = "E:\Installbits"
$SQLSetupFileDownloadFolderName = "sql-setup-download"
$SQLSetupDownloadFolderPath = Join-Path -Path $TempDir -ChildPath $SQLSetupFileDownloadFolderName

# now lets create the folder where we will down intall binaries
New-Item -ItemType Directory -Force  -Path $SQLSetupDownloadFolderPath


# now lets download sql server setup file from s3 bucket

$S3KeySQLSetupFile = "$S3KeyLocationForSQLServerSetupFile/$SQLServerSetupFileNameOnS3"
$S3KeySSRSSetupFile = "$S3KeyLocationForSSRSSetupFile/$SSRSSetupFileNameOnS3"
$S3KeySSMSSetupFile = "$S3KeyLocationForSSMSSetupFile/$SSMSSetupFileNameOnS3"

$S3KeySQLSetupConfigurationFile = "$S3KeyLocationForSQLServerSetupConfigurationFile/$SQLServerSetupConfigurationFileNameOnS3"

$S3KeyDefaultDatabaseCreationSQLFile = "$S3KeyLocationForDefaultDatabaseCreationSQLScriptFile/$DefaultDatabaseCreationSQLScriptFileNameOnS3"

$S3KeySQLServerPowerShellModuleFile = "$S3KeyLocationForSQLServerSetupFile/$SQLServerPowerShellModuleFileNameOnS3"




$SQLSetupDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SQLServerSetupFileNameOnS3
$SSRSSetupDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SSRSSetupFileNameOnS3
$SSMSSetupDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SSMSSetupFileNameOnS3
$SQLSetupConfigurationDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SQLServerSetupConfigurationFileNameOnLocal
$DefaultDatabaseCreationSQLFileDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $DefaultDatabaseCreationSQLScriptFileNameOnS3
$SQLPowerShellModuleDownloadFolderPathWithFileName = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $SQLServerPowerShellModuleFileNameOnS3

$SQLPowerShellModuleExtractFolderPath = "$Env:ProgramFiles\WindowsPowerShell\Modules\$SQLServerPowerShellModuleExtractFolderNameOnLocal"

$MonitoringScriptsLocalFolderPath = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $MonitoringScriptstFolderNameOnLocal
$BackupScriptsLocalFolderPath = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $BackupScriptstFolderNameOnLocal
$DBMailSetupScriptsLocalFolderPath = Join-Path -Path $SQLSetupDownloadFolderPath -ChildPath $DBMailSetupScriptstFolderNameOnLocal

#empty sql setup download folder
Remove-Item $SQLSetupDownloadFolderPath -Recurse -Force -ErrorAction SilentlyContinue

# Temp stop downloading file all the time
if ($InstallDatabaseEngine -eq "Yes")
{
    
    Write-Host "Downloading SQL Setup file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupFile"
    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeySQLSetupFile -LocalFile $SQLSetupDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable SQLServerSetupFileCopyError
    
    if ($SQLServerSetupFileCopyError -ge 1)
    {
        Write-Host "Error download SQL Server Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupFile. Error message is $SQLServerSetupFileCopyError. Stopping the installation"
        throw "Error download SQL Server Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupFile. Error message is $SQLServerSetupFileCopyError. Stopping the installation"
    }

    Write-Host "Downloading SQL Setup Configuration file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupConfigurationFile"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeySQLSetupConfigurationFile -LocalFile $SQLSetupConfigurationDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable SQLServerSetupConfigurationFileCopyError
    
    if ($SQLServerSetupConfigurationFileCopyError -ge 1)
    {
        Write-Host "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupConfigurationFile. Error message is $SQLServerSetupConfigurationFileCopyError. Stopping the installation"
        throw "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLSetupConfigurationFile. Error message is $SQLServerSetupConfigurationFileCopyError. Stopping the installation"
    }

    Write-Host "Downloading PowerShell SQl Server Module file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLServerPowerShellModuleFile"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeySQLServerPowerShellModuleFile -LocalFile $SQLPowerShellModuleDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable SQLPSModuleFileCopyError
    
    if ($SQLPSModuleFileCopyError -ge 1)
    {
        Write-Host "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLServerPowerShellModuleFile. Error message is $SQLPSModuleFileCopyError. Stopping the installation"
        throw "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySQLServerPowerShellModuleFile. Error message is $SQLPSModuleFileCopyError. Stopping the installation"
    }


    Write-Host "Downloading default database creation file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyDefaultDatabaseCreationSQLFile"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeyDefaultDatabaseCreationSQLFile -LocalFile $DefaultDatabaseCreationSQLFileDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable DefaultDBCreationFileCopyError
    
    if ($DefaultDBCreationFileCopyError -ge 1)
    {
        Write-Host "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyDefaultDatabaseCreationSQLFile. Error message is $DefaultDBCreationFileCopyError. Stopping the installation"
        throw "Error download SQL Server Setup Confuration file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyDefaultDatabaseCreationSQLFile. Error message is $DefaultDBCreationFileCopyError. Stopping the installation"
    }

    Write-Host "Downloading sql monitoring scripts from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForMonitoringScripts"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -KeyPrefix $S3KeyLocationForMonitoringScripts -LocalFolder $MonitoringScriptsLocalFolderPath -ErrorAction SilentlyContinue -ErrorVariable MonitoringScriptsCopyError
    

    if ($MonitoringScriptsCopyError -ge 1)
    {
        Write-Host "Error download SQL Server monitoring scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForMonitoringScripts. Error message is $MonitoringScriptsCopyError. Stopping the installation"
        throw "Error download SQL Server monitoring scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForMonitoringScripts. Error message is $MonitoringScriptsCopyError. Stopping the installation"
    }

    Write-Host "Downloading db mail setup scripts from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForDBMailSetupScripts"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -KeyPrefix $S3KeyLocationForDBMailSetupScripts -LocalFolder $DBMailSetupScriptsLocalFolderPath -ErrorAction SilentlyContinue -ErrorVariable DBmailScriptsCopyError
    

    if ($DBmailScriptsCopyError -ge 1)
    {
        Write-Host "Error downloading db mail scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForDBMailSetupScripts. Error message is $DBmailScriptsCopyError. Stopping the installation"
        throw "Error downloading db mail scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForDBMailSetupScripts. Error message is $DBmailScriptsCopyError. Stopping the installation"
    }

    Write-Host "Downloading backup scripts from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForBackupScripts"

    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -KeyPrefix $S3KeyLocationForBackupScripts -LocalFolder $BackupScriptsLocalFolderPath -ErrorAction SilentlyContinue -ErrorVariable BackupScriptsCopyError
    

    if ($BackupScriptsCopyError -ge 1)
    {
        Write-Host "Error downloading backup scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForBackupScripts. Error message is $BackupScriptsCopyError. Stopping the installation"
        throw "Error downloading backup scripts from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeyLocationForBackupScripts. Error message is $BackupScriptsCopyError. Stopping the installation"
    }

    InstallSQLDatabaseEngine 
}

if ($InstallReportingServices -eq "Yes")
{
    Write-Host "Downloading SQL Server Reporting Services Setup file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSRSSetupFile"
    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeySSRSSetupFile -LocalFile $SSRSSetupDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable SSRSSetupFileCopyError
    

    if ($SSRSSetupFileCopyError -ge 1)
    {
        Write-Host "Error downloading SQL Server Reporting Services Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSRSSetupFile. Error message is $SSRSSetupFileCopyError. Stopping the installation"
        throw "Error downloading SQL Server Reporting Services Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSRSSetupFile. Error message is $SSRSSetupFileCopyError. Stopping the installation"
    }

    InstallSQLServerReportingServices
}

if ($InstallSQLServerManagementStudio -eq "Yes")
{
    Write-Host "Downloading SQL Server Management Studio Setup file from s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSMSSetupFile"
    Copy-S3Object -BucketName $S3BucketNameForSQLServerRelatedArtifacts -Key $S3KeySSMSSetupFile -LocalFile $SSMSSetupDownloadFolderPathWithFileName -ErrorAction SilentlyContinue -ErrorVariable SSMSSetupFileCopyError
    

    if ($SSMSSetupFileCopyError -ge 1)
    {
        Write-Host "Error downloading SQL Server Management Studio Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSMSSetupFile. Error message is $SSMSSetupFileCopyError. Stopping the installation"
        throw "Error downloading SQL Server Management Studio Setup file from s3 location s3://$S3BucketNameForSQLServerRelatedArtifacts/$S3KeySSMSSetupFile. Error message is $SSMSSetupFileCopyError. Stopping the installation"
    }

    InstallSQLServerManagementStudio
}

Write-Host "installation completed"