# Creating RDS Custom SQL Server Using AWS CloudFormation Custom Resource.
* ## Prerequisites
    Please refer to AWS Documentation for what is required before creating Amazon RDS Custom SQL Server at [Setting up your environment for Amazon RDS Custom for SQL Server](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/custom-setup-sqlserver.html)

The following files are located at RDS Git repo [RDS Custom SQL Server](https://git.delta.com/aws/foundations-iac/-/tree/master/DeltaRDS/packages/rds-mssql-lambda-package/rds-custom)
* ## CFTs:
    * rds-instance-custom-mssql.yaml
    * rds-custom-mssql-saipoint-api.yaml
    * rds-custom-mssql-postcofig.yaml
* ## Lambda
    * lambda_function.py
    * custom_rds_mssql_instance.zip
## Creating Amazon RDS Custom SQL Server Using AWS Management Console and AWSCli
* Instructions are found at [Creating and connecting to a DB instance for Amazon RDS Custom for SQL Server](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/custom-creating-sqlserver.html)

## Create With Lambda Backed CloudFormation Custom Resource

1. Clone the Git repo that contains the CFT and Lambda function
2. Upload the Lambda zip file to an S3 bucket. Copy of the zip is located at `delta-rds-artifacts-us-east-1/mssql/lambdas/custom_rds_mssql_instance.zip` for region 1. You can use this location or upload file to any bucket within the same region that you are creating RDS Custom sqlserver. For region 2, use `delta-rds-artifacts-us-east-2/mssql/lambdas/custom_rds_mssql_instance.zip`.
3. Login to AWS Management console and navigate to the CloudFormation console.
4. To create the stack use the `rds-custom-mssql-saipoint-api.yaml` Cloudformation template and on CFN console click on **Create Stack** on drop down select **With New Resources(standard)**
5. Follow the rest of instuctions after uploading and applying all the required parameters to create the stack.
Launching this stack will create a Lambda function, two Security groups, IAM Lambda role and policy, Database Secret and secret policy, a CMK for secret and RDS Custom custom resource.

## Updating the Stack
When updating this stack, make sure not to carry out updates that are touching on the custom resource itself. Instead I recommend using the AWSCli to update the RDS Custom SQL server created through this stack. The following are the properties that can be updated after the RDS instance is created. Note that some updates may require a reboot of the SQL server. So make sure you know which of them will require a reboot of the instance.

* Use the __`aws rds modify-db-instance`__ command to modify any of the below properties.
* *DBInstanceIdentifier*
* *DBInstanceClass*
* *StorageType*
* *DeletionProtection*
* *AutomationMode*
* *Iops*
* *PreferredBackupWindow*
* *BackupRetentionPeriod*
* *PreferredMaintenanceWindow*

## Updating Tags on RDS Custom SQL Server
To update tags on the RDS Custom sqlserver, do not run the stack update. Instead use the AWSCli command `aws rds add-tags-to-resource` to update tags. 

## Creating SailPoint Group for RDS Custom SQL Server
* After creating the RDS sqlserver, wait until the instance is in _available_ state.
* Then, use the `rds-custom-mssql-saipoint-api.yaml` CFN template create a SailPoint group for your instance.
* The stack is going to create a Route 53 RecordSet and a Sailpoint group.
* To get details about the SailPoint group created, refer to the sailpoint Lambda CloudWatch logs.
* Refer to RDS custom underlying EC2 instance tags to get the alias name that is required to create the Route 53 RecordSet and SailPoint group.

## Before Joining Instance to Domain.
* The original instance profile used by the instance to be joined to domain **`AWSRDSCustomSQLServerInstanceProfile`**.
* The above instance profile will not allow you to run the SSM run command document meant to install additional security software and join the instance to domain.
* Use the **`DeltaMigrationEC2Role`** to run the postconfig and then switch back the original instance profile after postconfig tasks are complete.
## Joining RDS Custom SQL Server to Domain and Installing Required Security Software.
* Wait until the RDS Custom instance is done creating.
* Look for the SSM run command document by name **_rds-custom-sqlserver-postconfig_**.
* Open the run command and run it manually against your newly created instance.
* If you are running this in region 2, make sure that the bucket name is `delta-rds-artifacts-us-west-2`.
* If the **_rds-custom-sqlserver-postconfig_** run comand document does not exist, then use the `rds-custom-mssql-postcofig.yaml` CFN template to create one.
* If you are creating in region 2, change the bucket name to `delta-rds-artifacts-us-west-2`.



