"""
This lambda implements the custom resource handler for creating an RDS Custom 
MSSQL Server instance.

e.g.

CustomMsSQLServer:
    Type: Custom::RDSCustomMsSQL
    Version: "1.0"
    Properties:
      ServiceToken: !Ref FunctionArn
"""

from json import dumps
import os
import sys
import traceback
import urllib.request
import boto3
import os
import sys
from botocore.exceptions import ClientError
import json

def log_exception():
    """Log a stack trace"""
    exc_type, exc_value, exc_traceback = sys.exc_info()
    print(repr(traceback.format_exception(
        exc_type,
        exc_value,
        exc_traceback)))


def send_response(event, context, response):
    """Send a response to CloudFormation to handle the custom resource lifecycle"""
    response_body = {
        'Status': response,
        'Reason': 'See details in CloudWatch Log Stream: ' + \
            context.log_stream_name,
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
    }
    print('RESPONSE BODY: \n' + dumps(response_body))
    data = dumps(response_body).encode('utf-8')
    req = urllib.request.Request(
        event['ResponseURL'],
        data,
        headers={'Content-Length': len(data), 'Content-Type': ''})
    req.get_method = lambda: 'PUT'
    try:
        with urllib.request.urlopen(req) as resp:
            print(f'response.status: {resp.status}, ' +
                  f'response.reason: {resp.reason}')
            print('response from cfn: ' + resp.read().decode('utf-8'))
    except urllib.error.URLError:
        log_exception()
        raise Exception('Received non-200 response while sending response to AWS CloudFormation')
    return True

session = boto3.session.Session()
region = session.region_name
def custom_resource_handler(event, context):
    """
    This function creates a Custom RDS Instance.
    """
    #print("Event JSON: \n" + dumps(event))
    event_data = event['ResourceProperties']
    print(event_data)   
    # Get the secret values
    secret_arn = event_data['DBSecret']
    secret_json_data = get_secret(secret_arn)

    for key, value in secret_json_data.items():
      if key == 'username':
        username = value
      if key == 'password':
        password = value
    response = 'SUCCESS'
    db_identifier = event_data['DBIdentifier']
    rds_client = boto3.client('rds')
    if event['RequestType'] == 'Create':
        if event_data['StorageType'] == 'gp2':
            try:
                print("Creating custom db instance %s" % str(db_identifier))
                rds_instance = rds_client.create_db_instance(
                    DBInstanceIdentifier=db_identifier,
                    AllocatedStorage=int(event_data['DBAllocatedStorage']),
                    Engine=event_data['DBEngine'],
                    EngineVersion=event_data['EngineVersion'],
                    DBInstanceClass=event_data['DBInstanceClass'],
                    # General purpose SSD
                    StorageType=event_data['StorageType'],
                    StorageEncrypted=True,
                    KmsKeyId=event_data['RDSKmsKey'],
                    # Iops=DBIops,
                    AvailabilityZone=event_data['AvailabilityZone'],
                    DeletionProtection=True,
                    # Set this to true later?
                    MultiAZ=False,
                    CopyTagsToSnapshot=True,
                    DBSubnetGroupName=event_data['DBSubnetGroup'],
                    MasterUsername=username,
                    MasterUserPassword=password,
                    VpcSecurityGroupIds=[event_data['EC2SecurityGroupIds']],
                    CustomIamInstanceProfile=event_data['CustomIAMInstanceProfile'],
                    PreferredBackupWindow=event_data['DefinedBackupWindow'],
                    BackupRetentionPeriod=int(event_data['BackupRetentionPeriod']),
                    PreferredMaintenanceWindow=event_data['DefinedMaintenanceWindow'],
                    Tags=event_data['Tags'] #[{'Key': 'Alias', 'Value': f'{db_identifier}'}]
                )
                print(f'Custom db instance {db_identifier} has been created successfully.')
                response = 'SUCCESS'
            except ClientError as e:
                if e.response['Error']['Code'] == 'ParamValidationError':
                    print(f'There was an error {e} creating custom db instance ' +\
                        f'key {db_identifier} because of invalid parameter.')
                    response = 'FAILED'
                elif e.response['Error']['Code'] == 'KMSKeyNotAccessibleFault':
                    print(f"Verify that your role has permissions to access {event_data['RDSKmsKey']}")
                else:
                    log_exception()
            send_response(event, context, response)
            return
        
        elif event_data['StorageType'] == 'io1':
            try:
                print("Creating custom db instance %s" % str(db_identifier))
                rds_instance = rds_client.create_db_instance(
                    DBInstanceIdentifier=db_identifier,
                    AllocatedStorage=int(event_data['DBAllocatedStorage']),
                    Engine=event_data['DBEngine'],
                    EngineVersion=event_data['EngineVersion'],
                    DBInstanceClass=event_data['DBInstanceClass'],
                    # General purpose SSD
                    StorageType=event_data['StorageType'],
                    StorageEncrypted=True,
                    KmsKeyId=event_data['RDSKmsKey'],
                    # Iops=DBIops,
                    AvailabilityZone=event_data['AvailabilityZone'],
                    DeletionProtection=True,
                    # Set this to true later?
                    MultiAZ=False,
                    Iops=int(event_data['Iops']),
                    CopyTagsToSnapshot=True,
                    DBSubnetGroupName=event_data['DBSubnetGroup'],
                    MasterUsername=username,
                    MasterUserPassword=password,
                    VpcSecurityGroupIds=[event_data['EC2SecurityGroupIds']],
                    CustomIamInstanceProfile=event_data['CustomIAMInstanceProfile'],
                    PreferredBackupWindow=event_data['DefinedBackupWindow'],
                    BackupRetentionPeriod=int(event_data['BackupRetentionPeriod']),
                    PreferredMaintenanceWindow=event_data['DefinedMaintenanceWindow'],
                    Tags=event_data['Tags'] #[{'Key': 'Alias', 'Value': f'{db_identifier}'}]
                )
                print(f'Custom db instance {db_identifier} has been created successfully.')
                response = 'SUCCESS'
            except ClientError as e:
                if e.response['Error']['Code'] == 'ParamValidationError':
                    print(f'There was an error {e} creating custom db instance ' +\
                        f'key {db_identifier} because of invalid parameter.')
                    response = 'FAILED'
                elif e.response['Error']['Code'] == 'KMSKeyNotAccessibleFault':
                    print(f"Verify that your role has permissions to access {event_data['RDSKmsKey']}")
                else:
                    log_exception()
            send_response(event, context, response)
            return

    if event['RequestType'] == 'Update':
        # Do nothing and send a success immediately
        if event_data['StorageType'] == 'gp2':
            try:
                print("Modifying custom db instance %s" % str(db_identifier))
                rds_client.modify_db_instance(
                    DBInstanceIdentifier=db_identifier,
                    DBInstanceClass=event_data['DBInstanceClass'],
                    # General purpose SSD
                    StorageType=event_data['StorageType'],
                    DeletionProtection=True,
                    AutomationMode='full',
                    # Set this to true later?
                    ApplyImmediately=False,
                    PreferredBackupWindow=event_data['DefinedBackupWindow'],
                    BackupRetentionPeriod=int(event_data['BackupRetentionPeriod']),
                    PreferredMaintenanceWindow=event_data['DefinedMaintenanceWindow'],
                )
                print(f'Custom db instance {db_identifier} has been modified successfully.')
                response = 'SUCCESS'
            except ClientError as e:
                if e.response['Error']['Code'] == 'ParamValidationError':
                    print(f'There was an error {e} creating custom db instance ' +\
                        f'key {db_identifier} because of invalid parameter.')
                    response = 'FAILED'
                elif e.response['Error']['Code'] == 'KMSKeyNotAccessibleFault':
                    print(f"Verify that your role has permissions to access {event_data['RDSKmsKey']}")
                elif e.response['Error']['Code'] == 'InvalidDBInstanceStateFault':
                    print(f"Custom DB instance {db_identifier} can't be modified because it is in invalid state.")
                elif e.response['Error']['Code'] == 'DBInstanceNotFoundFault':
                    print(f"Custom DB instance {db_identifier} is not found.")
                else:
                    print(f'Custom DB instance {db_identifier} could not be modified!')
                    log_exception()
                    response = 'FAILED'
            send_response(event, context, response)
            return
        elif event_data['StorageType'] == 'io1':
            try:
                print("Modifying custom db instance %s" % str(db_identifier))
                rds_client.modify_db_instance(
                    DBInstanceIdentifier=db_identifier,
                    DBInstanceClass=event_data['DBInstanceClass'],
                    # General purpose SSD
                    StorageType=event_data['StorageType'],
                    DeletionProtection=True,
                    AutomationMode='full',
                    Iops=int(event_data['Iops']),
                    # Set this to true later?
                    ApplyImmediately=False,
                    PreferredBackupWindow=event_data['DefinedBackupWindow'],
                    BackupRetentionPeriod=int(event_data['BackupRetentionPeriod']),
                    PreferredMaintenanceWindow=event_data['DefinedMaintenanceWindow'],
                )
                print(f'Custom db instance {db_identifier} has been modified successfully.')
                response = 'SUCCESS'
            except ClientError as e:
                if e.response['Error']['Code'] == 'ParamValidationError':
                    print(f'There was an error {e} creating custom db instance ' +\
                        f'key {db_identifier} because of invalid parameter.')
                    response = 'FAILED'
                elif e.response['Error']['Code'] == 'KMSKeyNotAccessibleFault':
                    print(f"Verify that your role has permissions to access {event_data['RDSKmsKey']}")
                elif e.response['Error']['Code'] == 'InvalidDBInstanceStateFault':
                    print(f"Custom DB instance {db_identifier} can't be modified because it is in invalid state.")
                elif e.response['Error']['Code'] == 'DBInstanceNotFoundFault':
                    print(f"Custom DB instance {db_identifier} is not found.")
                else:
                    print(f'Custom DB instance {db_identifier} could not be modified!')
                    log_exception()
                    response = 'FAILED'
            send_response(event, context, response)
            return

    if event['RequestType'] == 'Delete':
        try:
            # Before deleting the db instance, deletion protection must be set to False
            print(f'Removing Deletion Protection on {db_identifier} before deletion.')
            rds_client.modify_db_instance(DBInstanceIdentifier=db_identifier, DeletionProtection=False)
            
            print(f"Deleting custom db instance {db_identifier}")
            del_db_instance = rds_client.delete_db_instance(DBInstanceIdentifier=db_identifier, DeleteAutomatedBackups=False, SkipFinalSnapshot=True)
            print(f'Custom db instance {db_identifier} has been deleted successfully.')
            response = 'SUCCESS'
        except Exception as e:
            print(f"There was an error {e} deleting custom db instance {db_identifier}")
            log_exception()
            response = 'FAILED'
        send_response(event, context, response)
def get_secret(secret_arn):
    """Gets the secret dictionary corresponding for the secret arn
        This helper function gets credentials for the arn
        Args:
                secret_arn (string): The secret ARN or other identifier
        Returns:
                secret_response: secret_response json
    """

    region_name =  region
    secret_manager_secret = session.client(
            service_name='secretsmanager',
            region_name=region_name,
    )

    try:
        get_secret_value_response = secret_manager_secret.get_secret_value(
            SecretId=secret_arn
        )
    except ClientError as e:
        print('error')
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            print("The requested secret " + secret_arn + " was not found")
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            print("The request was invalid due to:", e)
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            print("The request had invalid params:", e)
        elif e.response['Error']['Code'] == 'DecryptionFailure':
            print("The requested secret can't be decrypted using the provided KMS key:", e)
        elif e.response['Error']['Code'] == 'InternalServiceError':
            print("An error occurred on service side:", e)
        else :
            print(e.response)
    else:
        # Secrets Manager decrypts the secret value using the associated KMS CMK
        # Depending on whether the secret was a string or binary, only one of these fields will be populated
        if 'SecretString' in get_secret_value_response:
            text_secret_data = get_secret_value_response['SecretString']
            secret_response = json.loads(text_secret_data)
            return secret_response
        else:
            binary_secret_data = get_secret_value_response['SecretBinary']
        return binary_secret_data

def lambda_handler(event, context):
    """Lambda handler for the custom resource"""
    try:
        return custom_resource_handler(event, context)
    except Exception:
        log_exception()
        raise