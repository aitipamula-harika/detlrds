# RDS Post Lambda Package
Followw the below steps to package the lambda with sqlcmd client

## Download the Oracle instant client and tools in .zip format for your Linux-based operating system
* cd /tmp
* aws s3 cp s3://delta-postcfg-artifacts-us-east-1/database/tools/SqlCmd/mssql-tools-17.7.1.1-1.x86_64.rpm  ./mssql-tools-17.7.1.1-1.x86_64.rpm
* aws s3 cp s3://delta-postcfg-artifacts-us-east-1/database/tools/SqlCmd/msodbcsql17-17.8.1.1-1.x86_64.rpm  ./msodbcsql17-17.8.1.1-1.x86_64.rpm
* aws s3 cp s3://delta-postcfg-artifacts-us-east-1/database/tools/libtool-ltdl-2.4.2-22.el7_3.x86_64.rpm ./libtool-ltdl-2.4.2-22.el7_3.x86_64.rpm
* sudo yum -y install yum-utils rpmdevtools
* sudo yum download unixODBC -y
* sudo yum download unixODBC-devel
* sudo yumdownloader unixODBC-devel

## Install Virtual Environment
* sudo pip3 install virtualenv
* cd /tmp
* virtualenv awslambda
* source awslambda/bin/activate

## Set Permison
* sudo chmod 777  mssql-tools-17.7.1.1-1.x86_64.rpm msodbcsql17-17.8.1.1-1.x86_64.rpm unixODBC-devel-2.3.1-14.amzn2.x86_64.rpm libtool-ltdl-2.4.2-22.el7_3.x86_64.rpm

## Extract Packages
* sudo rpm2cpio ./mssql-tools-17.7.1.1-1.x86_64.rpm| cpio -idmv
* sudo rpm2cpio ./msodbcsql17-17.8.1.1-1.x86_64.rpm| cpio -idmv
* sudo rpm2cpio ./unixODBC-devel-2.3.1-14.amzn2.x86_64.rpm | cpio -idmv
* sudo rpm2cpio ./libtool-ltdl-2.4.2-22.el7_3.x86_64.rpm | cpio -idmv

## Copy Tools and Packages
* mkdir /var/task
* sudo cp -r /opt/mssql-tools/bin /var/task
* sudo cp -r /opt/mssql-tools/share /var/task
* sudo cp -r ./usr/lib64/lib* /var/task
* sudo cp -r /opt/microsoft/* /var/task

## Create ini file to locate driver
cat <<EOF > /var/task/odbcinst.ini
[ODBC Driver 17 for SQL Server]
Description=Microsoft ODBC Driver 17 for SQL Server
Driver=/var/task/msodbcsql17/lib64/libmsodbcsql-17.8.so.1.1
UsageCount=1
EOF

## Set Library Path
* export LD_LIBRARY_PATH=$PWD
* export ODBCSYSINI=./microsoft/msodbcsql17/etc

## Package the Lambda
* cd /tmp/archive_aws_lambda
* Note: Add or Create lambda_function.py file before package
* zip -r -y -9 /tmp/awslambdapkg_rds_mssql_post.zip *
* sudo chmod 777 /tmp/awslambdapkg_rds_mssql_post.zip
