--CREATE DB
CREATE DATABASE $(DBName)
SELECT name, database_id, create_date FROM sys.databases
GO

