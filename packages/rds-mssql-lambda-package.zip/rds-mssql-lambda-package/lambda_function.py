import subprocess, os, sys
import botocore, boto3
import json
import random
import logging
import time
import ntpath
from pathlib import Path
import os
import urllib3
import zipfile
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    import liblogging
except ImportError:
    pass

session = boto3.session.Session()

def lambda_handler(event, context):
  """RDS mssql Post script handler
  This handler will be used to run the sql script after RDS oracle craeted
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - BucketName: The s3 bucket to download the scripts
      - ScriptPath: The shell scripts name to connect db and run sql script
      - SecretArn: The RDS oracle db master username password
      - DbEndPoint: The sql script, which cotains the queryr
      - DbEndPoint: The db endpoint
      - SqlScriptPath: The Sql script path
      - Database: The name of the data base
      - ZipArchivePath: The zip archive that contains SDS DB partitions.
    context (LambdaContext): The Lambda runtime information
    Raises:
    """

  if(event['RequestType'] == 'Delete'):
      logger.info("Lambda Cutom invoke: " + event['RequestType'])
      send(event, context, "SUCCESS", {})


  shell_script_local_path = '/tmp/post-script.sh'
  sql_script_local_path = '/tmp/sql-script.sql'
  username = ''
  password = ''
  host = ''
  dbname = ''

  try:
    #Retrive from event
    bucket_name = gets3bucket(event)
    script_name = getscriptname(event)
    secret_arn = getsecretarn(event)
    sql_script_name = getsqlscriptname(event)
    host = getdbHost(event)
    dbname = getdbName(event)

    block_code = ''
    env = ''
    dbnumber = ''
    dbnumbersuffix = ''

    #Get blockcode and env
    if(event['RequestType'] == 'Create' or event['RequestType'] == 'Update' ):
      block_code = getblockcode(event)
      env = getenv(event)
      dbnumber = getdbnumber(event)
      dbnumbersuffix =  getdbnumbersuffix(event)

    #Get shell script
    download_s3_object(bucket_name, script_name, shell_script_local_path)

    #Get sql script
    download_s3_object(bucket_name, sql_script_name, sql_script_local_path)

    #Get secret values
    logger.info("Retrieve secret started")
    secret_json_data = get_secret(secret_arn)

    for key, value in secret_json_data.items():
      if key == 'username':
        username = value
      if key == 'password':
        password = value

    if(event['RequestType'] == 'Create' or event['RequestType'] == 'Update' ):
      dbname = "sql_" + block_code + "_"  + env + dbnumber + "_" + dbnumbersuffix

    logger.info("Retrieve secret completed")

    modifiedPassword = quote_argument(password)

    if(event['RequestType'] == 'Create'):
      logger.info("Lambda Cutom invoke: " + event['RequestType'])
      logger.info("Script execution started")
      os.system('sh "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}"'.format(str(shell_script_local_path), str(username), str(modifiedPassword), str(host), str(dbname), str(sql_script_name), str(block_code), str(env), str(dbnumber), str(dbnumbersuffix)))
      logger.info("Script execution completed")
      send(event, context, "SUCCESS", {})
    elif(event['RequestType'] == 'Update'):
      logger.info("Lambda Cutom invoke: " + event['RequestType'])
      logger.info("Script execution started")
      os.system('sh "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}" "{}"'.format(str(shell_script_local_path), str(username), str(modifiedPassword), str(host), str(dbname), str(sql_script_name), str(block_code), str(env), str(dbnumber), str(dbnumbersuffix)))
      logger.info("Script execution completed")
      send(event, context, "SUCCESS", {})
    elif(event['RequestType'] == 'Job' or event['RequestType'] == 'CLI' ):
      logger.info("Lambda Cutom invoke: " + event['RequestType'])
      os.system('sh "{}" "{}" "{}" "{}" "{}" "{}"'.format(str(shell_script_local_path),str(username), str(modifiedPassword),str(host), str(dbname), str(sql_script_name)))

  except:
    if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
      logger.info("Error occur while processing post script: " + event['RequestType'])
    else:
      send(event, context, "FAILED", {})
    raise

def gets3bucket(event):
  """get bucket name from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - BucketName: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['BucketName']
  else:
    return event['ResourceProperties']['BucketName']

def getscriptname(event):
  """get ScriptPath from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['ScriptPath']
  else:
    return event['ResourceProperties']['ScriptPath']

def getsecretarn(event):
  """get SecretArn from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['SecretArn']
  else:
    return event['ResourceProperties']['SecretArn']

def getsqlscriptname(event):
  """get SqlScriptPath from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['SqlScriptPath']
  else:
    return event['ResourceProperties']['SqlScriptPath']

def getblockcode(event):
  """get blockcode from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['BlockCode']
  else:
    return event['ResourceProperties']['BlockCode']

def getenv(event):
  """get blockcode from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['Env']
  else:
    return event['ResourceProperties']['Env']

def getdbnumber(event):
  """get blockcode from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['DbNumber']
  else:
    return event['ResourceProperties']['DbNumber']

def getdbnumbersuffix(event):
  """get blockcode from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['DbNumberSuffix']
  else:
    return event['ResourceProperties']['DbNumberSuffix']

def getdbHost(event):
  """get dbhostname from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['DbEndpoint']
  else:
    return event['ResourceProperties']['DbEndpoint']

def getdbName(event):
  """get dbhostname from event
  Args:
    event (dict): Lambda dictionary of event parameters. These keys must include the following:
      - RequestType: The s3 bucket to download the scripts
    """
  if event['RequestType'] == 'Job' or event['RequestType'] == 'CLI':
    return event['DbName']
  else:
    return event['ResourceProperties']['DbName']

def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False):
  """send response back via CFT api
    """
  responseUrl = event['ResponseURL']
  print(responseUrl)
  responseBody = {}
  responseBody['Status'] = responseStatus
  responseBody['Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
  responseBody['PhysicalResourceId'] = physicalResourceId or context.log_stream_name
  responseBody['StackId'] = event['StackId']
  responseBody['RequestId'] = event['RequestId']
  responseBody['LogicalResourceId'] = event['LogicalResourceId']
  responseBody['NoEcho'] = noEcho
  responseBody['Data'] = responseData
  json_responseBody = json.dumps(responseBody)
  print("Response body:\n" + json_responseBody)
  headers = {
      'content-type' : '',
      'content-length' : str(len(json_responseBody)) }

  try:
    http = urllib3.PoolManager()
    response = http.request('PUT',
                              responseUrl,
                              body=json_responseBody,
                              headers=headers)
    print("Status code: " + response.reason)
  except Exception as e:
    print("send(..) failed executing requests.put(..): " + str(e))

def download_s3_object(bucket, key, path_to_download):
  """Downloads the objects from s3
  This helper function downloads object from s3 to local path
  Args:
    bucket: The name of the s3 bucket
    key: the object name
    path_to_download: The local path to download file
  Returns:
    secret_response: secret_response json
  """

  s3 = session.client('s3')

  try:
    logger.info("File Download Started: " + bucket+"/"+key)
    s3.download_file(bucket, key, path_to_download)
    logger.info("File Download Completed: " + path_to_download)
  except Exception as e:
    logger.error(e)
    logger.error('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
    raise e

def get_secret(secret_arn):
  """Gets the secret dictionary corresponding for the secret arn
  This helper function gets credentials for the arn
  Args:
        secret_arn (string): The secret ARN or other identifier
  Returns:
        secret_response: secret_response json
  """

  region_name =  os.environ['AWS_REGION']

  secret_manager_secret = session.client(
        service_name='secretsmanager',
        region_name=region_name,
  )

  try:
    get_secret_value_response = secret_manager_secret.get_secret_value(
        SecretId=secret_arn
    )
  except ClientError as e:
    logger.info('error')
    if e.response['Error']['Code'] == 'ResourceNotFoundException':
        logger.error("The requested secret " + secret_arn + " was not found")
    elif e.response['Error']['Code'] == 'InvalidRequestException':
        logger.error("The request was invalid due to:", e)
    elif e.response['Error']['Code'] == 'InvalidParameterException':
        logger.error("The request had invalid params:", e)
    elif e.response['Error']['Code'] == 'DecryptionFailure':
        logger.error("The requested secret can't be decrypted using the provided KMS key:", e)
    elif e.response['Error']['Code'] == 'InternalServiceError':
        logger.error("An error occurred on service side:", e)
    else :
        logger.error(e.response)
  else:
    # Secrets Manager decrypts the secret value using the associated KMS CMK
    # Depending on whether the secret was a string or binary, only one of these fields will be populated
    if 'SecretString' in get_secret_value_response:
      text_secret_data = get_secret_value_response['SecretString']
      secret_response = json.loads(text_secret_data)
      return secret_response
    else:
      binary_secret_data = get_secret_value_response['SecretBinary']
      return binary_secret_data

def quote_argument(argument):
  """transform the password with escape character
    """
  return '"%s"' % (
        argument
        .replace('\\', '\\\\')
        .replace('"', '\\"')
        .replace('$', '\\$')
        .replace('`', '\\`')
        .replace(']', '\\]')
        .replace('^', '\\^')
        .replace('*', '\\*')
        .replace('.', '\\.')
        .replace("'", "\\'")
        .replace("&", "\\&")
        .replace("(", "\\(")
        .replace(")", "\\)")
        .replace("+", "\\+")
        .replace("-", "\\-")
        .replace(".", "\\.")
        .replace("_", "\\_")
        .replace(";", "\\;")
        .replace("=", "\\=")
        .replace(":", "\\:")
        .replace("#", "\\#")
        .replace("<", "\\<")
        .replace(">", "\\>")
  )
