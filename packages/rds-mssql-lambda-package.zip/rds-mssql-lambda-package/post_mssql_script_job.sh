#!/bin/bash
RETVAL=$(./bin/sqlcmd -x -U "${1}"  -P"${2}" -S ${3},1433 -i"//tmp//sql-script.sql")
echo $RETVAL
