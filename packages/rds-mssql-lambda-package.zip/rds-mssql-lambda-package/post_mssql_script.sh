#!/bin/bash
RETVAL=$(./bin/sqlcmd -U "${1}"  -P"${2}" -S ${3},1433  -i"//tmp//sql-script.sql" -v "DBName=${4}" )
echo $RETVAL


